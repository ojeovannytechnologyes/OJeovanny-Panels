#!/data/data/com.termux/files/usr/bin/bash
# build.sh
# Compila o WifiRemote e copia o APK pronto pra pasta Download.
# Rode de dentro da pasta WifiRemote: bash build.sh

set -e

export ANDROID_HOME="$HOME/android-sdk"
export PATH="$PATH:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$HOME/gradle-8.7/bin"

echo "sdk.dir=$ANDROID_HOME" > local.properties

# Corrige um problema comum: o Gradle baixa o aapt2 pra x86_64, que não roda
# em celular (ARM). Aqui forçamos ele a usar o aapt2 certo do Android SDK.
AAPT2_PATH="$ANDROID_HOME/build-tools/34.0.0/aapt2"
mkdir -p "$HOME/.gradle"
if ! grep -q "aapt2FromMavenOverride" "$HOME/.gradle/gradle.properties" 2>/dev/null; then
  echo "android.aapt2FromMavenOverride=$AAPT2_PATH" >> "$HOME/.gradle/gradle.properties"
fi

echo "== Compilando APK (debug) =="
gradle assembleDebug --no-daemon

APK_PATH="app/build/outputs/apk/debug/app-debug.apk"

if [ -f "$APK_PATH" ]; then
  DEST="/sdcard/Download/WifiRemote.apk"
  cp "$APK_PATH" "$DEST"
  echo ""
  echo "✅ Build concluído!"
  echo "APK copiado para: $DEST"
  echo "Abra o app de Arquivos do celular, vá em Download e toque no WifiRemote.apk para instalar."
else
  echo "❌ Build falhou - confira os erros acima."
fi
