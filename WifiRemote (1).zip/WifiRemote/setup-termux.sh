#!/data/data/com.termux/files/usr/bin/bash
# setup-termux.sh
# Prepara o ambiente de build Android dentro do Termux (sem proot).
# Rode uma vez só: bash setup-termux.sh

set -e

echo "== Atualizando pacotes =="
pkg update -y
pkg upgrade -y

echo "== Instalando JDK 17, wget, unzip, git =="
pkg install -y openjdk-17 wget unzip git

echo "== Autorizando acesso ao armazenamento (aceite a permissão no popup) =="
termux-setup-storage || true

export ANDROID_HOME="$HOME/android-sdk"
mkdir -p "$ANDROID_HOME/cmdline-tools"

if [ ! -d "$ANDROID_HOME/cmdline-tools/latest" ]; then
  echo "== Baixando Android SDK command-line tools =="
  cd "$HOME"
  wget -O cmdline-tools.zip https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip
  unzip -q cmdline-tools.zip -d "$ANDROID_HOME/cmdline-tools"
  mv "$ANDROID_HOME/cmdline-tools/cmdline-tools" "$ANDROID_HOME/cmdline-tools/latest"
  rm cmdline-tools.zip
fi

export PATH="$PATH:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools"

echo "== Aceitando licenças do SDK =="
yes | sdkmanager --licenses > /dev/null || true

echo "== Instalando plataformas e build-tools =="
sdkmanager "platform-tools" "platforms;android-34" "build-tools;34.0.0"

if [ ! -d "$HOME/gradle-8.7" ]; then
  echo "== Baixando Gradle 8.7 =="
  cd "$HOME"
  wget -O gradle.zip https://services.gradle.org/distributions/gradle-8.7-bin.zip
  unzip -q gradle.zip
  rm gradle.zip
fi

export PATH="$PATH:$HOME/gradle-8.7/bin"

echo "== Salvando variáveis de ambiente no .bashrc (pra não precisar exportar de novo) =="
{
  echo ''
  echo '# --- Android build (adicionado pelo setup-termux.sh) ---'
  echo 'export ANDROID_HOME=$HOME/android-sdk'
  echo 'export PATH=$PATH:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$HOME/gradle-8.7/bin'
} >> "$HOME/.bashrc"

echo ""
echo "Setup concluído! Feche e reabra o Termux (ou rode: source ~/.bashrc)"
echo "Depois, use build.sh dentro da pasta do projeto WifiRemote para compilar."
