package com.wifiremote.app

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import dadb.AdbKeyPair
import dadb.Dadb
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : AppCompatActivity() {

    private var dadb: Dadb? = null
    private lateinit var statusText: TextView
    private lateinit var ipInput: EditText
    private val scope = CoroutineScope(Dispatchers.Main)

    // Códigos de tecla padrão do Android (android.view.KeyEvent)
    private object Key {
        const val UP = 19
        const val DOWN = 20
        const val LEFT = 21
        const val RIGHT = 22
        const val OK = 66
        const val BACK = 4
        const val HOME = 3
        const val VOL_UP = 24
        const val VOL_DOWN = 25
        const val POWER = 26
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        ipInput = findViewById(R.id.ipInput)
        ipInput.setText(getSavedIp())

        findViewById<Button>(R.id.btnConnect).setOnClickListener { connect() }
        findViewById<Button>(R.id.btnUp).setOnClickListener { sendKeyEvent(Key.UP) }
        findViewById<Button>(R.id.btnDown).setOnClickListener { sendKeyEvent(Key.DOWN) }
        findViewById<Button>(R.id.btnLeft).setOnClickListener { sendKeyEvent(Key.LEFT) }
        findViewById<Button>(R.id.btnRight).setOnClickListener { sendKeyEvent(Key.RIGHT) }
        findViewById<Button>(R.id.btnOk).setOnClickListener { sendKeyEvent(Key.OK) }
        findViewById<Button>(R.id.btnBack).setOnClickListener { sendKeyEvent(Key.BACK) }
        findViewById<Button>(R.id.btnHome).setOnClickListener { sendKeyEvent(Key.HOME) }
        findViewById<Button>(R.id.btnVolUp).setOnClickListener { sendKeyEvent(Key.VOL_UP) }
        findViewById<Button>(R.id.btnVolDown).setOnClickListener { sendKeyEvent(Key.VOL_DOWN) }
        findViewById<Button>(R.id.btnPower).setOnClickListener { sendKeyEvent(Key.POWER) }

        // Conecta automaticamente ao abrir, usando o último IP salvo
        connect()
    }

    private fun getSavedIp(): String {
        val prefs = getSharedPreferences("wifi_remote", MODE_PRIVATE)
        return prefs.getString("ip", "10.0.0.191") ?: "10.0.0.191"
    }

    private fun saveIp(ip: String) {
        getSharedPreferences("wifi_remote", MODE_PRIVATE).edit().putString("ip", ip).apply()
    }

    /**
     * Gera (na primeira vez) ou reutiliza um par de chaves RSA próprio do app.
     * É essencial reutilizar a mesma chave sempre - é o que permite que o
     * projetor "lembre" da autorização depois da primeira vez, em vez de
     * pedir confirmação toda hora.
     */
    private fun getKeyPair(): AdbKeyPair {
        val privateKeyFile = File(filesDir, "adbkey")
        val publicKeyFile = File(filesDir, "adbkey.pub")
        return if (privateKeyFile.exists() && publicKeyFile.exists()) {
            AdbKeyPair.read(privateKeyFile, publicKeyFile)
        } else {
            AdbKeyPair.generate(privateKeyFile, publicKeyFile)
        }
    }

    private fun connect() {
        val ip = ipInput.text.toString().trim()
        if (ip.isEmpty()) {
            Toast.makeText(this, "Digite o IP do projetor", Toast.LENGTH_SHORT).show()
            return
        }
        saveIp(ip)
        statusText.text = "Conectando a $ip..."
        scope.launch {
            try {
                val connection = withContext(Dispatchers.IO) {
                    Dadb.create(ip, 5555, getKeyPair())
                }
                dadb = connection
                statusText.text =
                    "Conectado a $ip.\nSe aparecer um aviso na tela do projetor pedindo autorização, aceite com o controle físico (só precisa fazer isso uma vez)."
            } catch (e: Exception) {
                statusText.text = "Falha ao conectar em $ip: ${e.message}"
            }
        }
    }

    private fun sendKeyEvent(code: Int) {
        val connection = dadb
        if (connection == null) {
            Toast.makeText(this, "Ainda não conectado - toque em Conectar", Toast.LENGTH_SHORT).show()
            return
        }
        scope.launch {
            try {
                withContext(Dispatchers.IO) {
                    connection.shell("input keyevent $code")
                }
            } catch (e: Exception) {
                statusText.text = "Erro ao enviar comando: ${e.message}"
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            dadb?.close()
        } catch (e: Exception) {
            // ignora erro ao fechar
        }
    }
}
