# Wifi Remote — Controle via ADB pela rede local

Controla o projetor HY320 mandando comandos ADB pela Wi-Fi, sem precisar
instalar nada no projetor. Funciona em qualquer Android (mínimo Android 5),
inclusive o celular do seu pai com Android 7.1.2.

## Antes de instalar (feito uma vez, direto no projetor com o controle físico)

1. Configurações > Sobre > toque 7 vezes em "Número da versão/Build" para
   liberar as Opções do desenvolvedor.
2. Opções do desenvolvedor > ative "Depuração via rede" / "Depuração USB"
   (nome varia conforme a versão).
3. Confirme o IP do projetor em Configurações > Wi-Fi > toque na rede
   conectada > Endereço IP. No seu caso: `10.0.0.191`.

## Como compilar e instalar no celular do seu pai

1. Instale o Android Studio.
2. Abra a pasta `WifiRemote` como projeto.
3. Deixe o Gradle sincronizar (baixa a biblioteca `dadb` automaticamente —
   precisa de internet na primeira vez).
4. Conecte o celular do seu pai via USB com Depuração USB ativada nele
   (só pra instalar o app; depois disso não precisa mais de USB).
5. Rode (▶) para instalar.

## Como usar

1. Abra o app — o IP `10.0.0.191` já vem preenchido.
2. Toque em **Conectar**.
3. **Na primeira conexão**, deve aparecer um pop-up na tela do projetor
   pedindo autorização (algo como "Permitir depuração USB deste
   computador?"). Aceite usando o controle físico do projetor e marque
   "sempre permitir deste computador" se a opção existir — assim não
   precisa autorizar de novo nas próximas vezes.
4. Depois de conectado, use os botões de seta, OK, Voltar, Home, Volume
   e Power.

## Se não conectar

- Confirme que o celular e o projetor estão na mesma rede Wi-Fi.
- Confirme que "Depuração via rede/USB" continua ativada no projetor
  (algumas ROMs desativam depois de reiniciar o aparelho).
- Se o IP mudou (o roteador pode trocar o IP com o tempo), digite o novo
  IP no campo do app.
- Se aparecer erro de conexão recusada, o serviço ADB pode não estar
  escutando na porta 5555 nessa ROM específica — nesse caso me avise que
  buscamos outra porta ou abordagem.

## Compilando direto no Termux (sem PC, sem Android Studio)

Dá pra compilar esse projeto inteiro no próprio celular, usando o Termux
puro (sem proot). É mais demorado que usar o Android Studio (o SDK e o
Gradle somados passam de 1GB de download), mas funciona.

**Requisitos**: celular com uns 4GB livres e Wi-Fi (vai baixar bastante
coisa na primeira vez), Termux instalado via **F-Droid** (não use a
versão da Play Store).

### Passo 1 — Preparar o ambiente (uma vez só)

Copie a pasta `WifiRemote` inteira para dentro do celular (ex: em
`/sdcard/Download/WifiRemote`), abra o Termux, entre na pasta e rode:

```bash
termux-setup-storage
cd /sdcard/Download/WifiRemote
bash setup-termux.sh
```

Isso instala Java, baixa o Android SDK e o Gradle. Pode demorar bastante
(vários minutos) dependendo da conexão. Ao final, feche e reabra o
Termux.

### Passo 2 — Compilar

Ainda dentro da pasta do projeto:

```bash
bash build.sh
```

Se der tudo certo, o APK final aparece em `/sdcard/Download/WifiRemote.apk`
— é só abrir pelo gerenciador de arquivos do celular e instalar
(pode pedir pra habilitar "instalar de fontes desconhecidas" na primeira
vez).

### Problemas comuns

- **"aapt2: cannot execute binary file"** — o script `build.sh` já corrige
  isso automaticamente apontando pro aapt2 certo do Android SDK, mas se
  ainda acontecer, confira se o arquivo existe em
  `~/android-sdk/build-tools/34.0.0/aapt2`.
- **Erro de licença do SDK não aceita** — rode de novo:
  `yes | sdkmanager --licenses`
- **Ficou sem espaço** — o SDK + Gradle + cache de dependências passam de
  1.5GB no total; libere espaço e tente de novo.
- **Build muito lento / trava** — normal na primeira vez (baixa tudo);
  builds seguintes são bem mais rápidas porque tudo fica em cache.

## Personalizando botões

Os códigos de tecla usados (`Key.UP`, `Key.DOWN` etc, em `MainActivity.kt`)
são os códigos padrão do Android (`android.view.KeyEvent`). Para adicionar
mais botões (Play/Pause = 85, Mute = 164, Menu = 82, etc), basta acrescentar
a constante e um botão novo no layout chamando `sendKeyEvent(código)`.
