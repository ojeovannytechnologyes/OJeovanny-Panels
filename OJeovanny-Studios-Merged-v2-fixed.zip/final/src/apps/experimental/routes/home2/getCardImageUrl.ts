import type { Api } from '@jellyfin/sdk';
import { ImageType } from '@jellyfin/sdk/lib/generated-client/models/image-type';
import { getImageApi } from '@jellyfin/sdk/lib/utils/api/image-api';

import type { ItemDto } from 'types/base/models/item-dto';

interface GetItemImageUrlOptions {
    fillWidth?: number;
    fillHeight?: number;
}

/**
 * Resolves a background image URL for an item, preferring the requested
 * imageType and falling back to a backdrop if no primary/thumb tag exists.
 * Returns undefined when there is no usable image, so the caller can fall
 * back to the decorative gradient + item name treatment used by the mockup.
 */
export function getItemImageUrl(
    api: Api | undefined,
    item: ItemDto,
    imageType: ImageType,
    options: GetItemImageUrlOptions = {}
): string | undefined {
    if (!api || !item.Id) return undefined;

    const hasRequestedTag = item.ImageTags?.[imageType];
    const hasBackdrop = item.BackdropImageTags?.length;

    if (!hasRequestedTag && !hasBackdrop) return undefined;

    const resolvedType = hasRequestedTag ? imageType : ImageType.Backdrop;

    return getImageApi(api).getItemImageUrlById(item.Id, resolvedType, {
        fillWidth: options.fillWidth,
        fillHeight: options.fillHeight,
        quality: 90
    });
}

export { ImageType };
