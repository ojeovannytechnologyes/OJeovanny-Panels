import React, { type FC } from 'react';
import { Link } from 'react-router-dom';

import { appRouter } from 'components/router/appRouter';
import globalize from 'lib/globalize';
import type { ItemDto } from 'types/base/models/item-dto';

export interface NavLinkItem {
    key: string;
    label: string;
    url: string;
    isActive: boolean;
}

export const buildNavLinks = (userViews: ItemDto[] | undefined): NavLinkItem[] => {
    const links: NavLinkItem[] = [
        {
            key: 'home',
            label: globalize.translate('Home'),
            url: 'home2',
            isActive: true
        }
    ];

    const seriesView = userViews?.find(v => v.CollectionType === 'tvshows');
    const moviesView = userViews?.find(v => v.CollectionType === 'movies');

    links.push({
        key: 'series',
        label: globalize.translate('Series'),
        url: seriesView ? appRouter.getRouteUrl(seriesView, { context: seriesView.CollectionType ?? undefined }).substring(1) : 'home2',
        isActive: false
    });

    links.push({
        key: 'movies',
        label: globalize.translate('Movies'),
        url: moviesView ? appRouter.getRouteUrl(moviesView, { context: moviesView.CollectionType ?? undefined }).substring(1) : 'home2',
        isActive: false
    });

    links.push({
        key: 'favorites',
        label: globalize.translate('Favorites'),
        url: 'list?serverId=&IsFavorite=true',
        isActive: false
    });

    return links;
};

interface HomeNavProps {
    navLinks: NavLinkItem[];
}

const HomeNav: FC<HomeNavProps> = ({ navLinks }) => {
    return (
        <nav className='oj-nav'>
            <div className='oj-logo'>
                OJeovanny
                <span>Studios</span>
            </div>
            <div className='oj-nav-links'>
                {navLinks.map(link => (
                    <Link
                        key={link.key}
                        className={`oj-nav-link${link.isActive ? ' active' : ''}`}
                        to={`/${link.url}`}
                    >
                        {link.label}
                    </Link>
                ))}
            </div>
            <div className='oj-nav-icons'>
                <Link to='/search'>
                    <i className='ti ti-search' aria-hidden='true' />
                </Link>
                <i className='ti ti-bell' aria-hidden='true' />
                <Link to='/quickconnect'>
                    <i className='ti ti-user-circle' aria-hidden='true' />
                </Link>
            </div>
        </nav>
    );
};

export default HomeNav;
