import React, { type FC } from 'react';
import { Link } from 'react-router-dom';

import globalize from 'lib/globalize';
import type { NavLinkItem } from './HomeNav';

const BOTTOM_ICONS: Record<string, string> = {
    home: 'ti-home',
    series: 'ti-device-tv',
    movies: 'ti-movie',
    favorites: 'ti-heart'
};

interface BottomNavProps {
    navLinks: NavLinkItem[];
}

const BottomNav: FC<BottomNavProps> = ({ navLinks }) => {
    return (
        <div className='oj-bottom-nav'>
            {navLinks.map(link => (
                <Link
                    key={link.key}
                    className={`oj-bottom-item${link.isActive ? ' active' : ''}`}
                    to={`/${link.url}`}
                >
                    <i className={`ti ${BOTTOM_ICONS[link.key] ?? 'ti-circle'}`} aria-hidden='true' />
                    <span>{link.label}</span>
                    {link.isActive && <div className='oj-accent-line' />}
                </Link>
            ))}
            <Link className='oj-bottom-item' to='/mypreferencesmenu'>
                <i className='ti ti-settings' aria-hidden='true' />
                <span>{globalize.translate('Settings')}</span>
            </Link>
        </div>
    );
};

export default BottomNav;
