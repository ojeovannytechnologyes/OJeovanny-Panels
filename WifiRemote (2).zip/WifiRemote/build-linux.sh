#!/bin/bash
# build-linux.sh
# Compila o WifiRemote numa instância Linux comum e deixa o APK pronto
# na pasta atual. Rode de dentro da pasta WifiRemote: bash build-linux.sh

set -e

export ANDROID_HOME="$HOME/android-sdk"
export PATH="$PATH:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$HOME/gradle-8.7/bin"

echo "sdk.dir=$ANDROID_HOME" > local.properties

echo "== Compilando APK (debug) =="
gradle assembleDebug --no-daemon

APK_PATH="app/build/outputs/apk/debug/app-debug.apk"

if [ -f "$APK_PATH" ]; then
  cp "$APK_PATH" ./WifiRemote.apk
  echo ""
  echo "✅ Build concluído!"
  echo "APK gerado em: $(pwd)/WifiRemote.apk"
  echo "Transfira esse arquivo pro celular (por cabo, Google Drive, Telegram, etc)"
  echo "e instale abrindo ele no gerenciador de arquivos do celular."
else
  echo "❌ Build falhou - confira os erros acima."
fi
