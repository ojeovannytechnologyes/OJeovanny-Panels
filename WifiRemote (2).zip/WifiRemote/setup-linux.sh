#!/bin/bash
# setup-linux.sh
# Prepara o ambiente de build Android numa instância Linux comum
# (Ubuntu/Debian, x86_64). Rode uma vez só: bash setup-linux.sh

set -e

echo "== Instalando JDK 17, wget, unzip =="
sudo apt-get update -y
sudo apt-get install -y openjdk-17-jdk wget unzip

export ANDROID_HOME="$HOME/android-sdk"
mkdir -p "$ANDROID_HOME/cmdline-tools"

if [ ! -d "$ANDROID_HOME/cmdline-tools/latest" ]; then
  echo "== Baixando Android SDK command-line tools =="
  cd "$HOME"
  wget -O cmdline-tools.zip https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip
  unzip -q cmdline-tools.zip -d "$ANDROID_HOME/cmdline-tools"
  mv "$ANDROID_HOME/cmdline-tools/cmdline-tools" "$ANDROID_HOME/cmdline-tools/latest"
  rm cmdline-tools.zip
fi

export PATH="$PATH:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools"

echo "== Aceitando licenças do SDK =="
yes | sdkmanager --licenses > /dev/null || true

echo "== Instalando plataformas e build-tools =="
sdkmanager "platform-tools" "platforms;android-34" "build-tools;34.0.0"

if [ ! -d "$HOME/gradle-8.7" ]; then
  echo "== Baixando Gradle 8.7 =="
  cd "$HOME"
  wget -O gradle.zip https://services.gradle.org/distributions/gradle-8.7-bin.zip
  unzip -q gradle.zip
  rm gradle.zip
fi

export PATH="$PATH:$HOME/gradle-8.7/bin"

echo "== Salvando variáveis de ambiente no .bashrc =="
{
  echo ''
  echo '# --- Android build (adicionado pelo setup-linux.sh) ---'
  echo 'export ANDROID_HOME=$HOME/android-sdk'
  echo 'export PATH=$PATH:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$HOME/gradle-8.7/bin'
} >> "$HOME/.bashrc"

echo ""
echo "Setup concluído! Rode: source ~/.bashrc"
echo "Depois use build-linux.sh dentro da pasta do projeto para compilar."
