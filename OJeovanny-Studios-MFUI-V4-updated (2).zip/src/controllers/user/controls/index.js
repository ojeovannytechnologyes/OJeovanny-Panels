import layoutManager from 'components/layoutManager';
import toast from '../../../components/toast/toast';
import globalize from '../../../lib/globalize';
import appSettings from '../../../scripts/settings/appSettings';
import gamepadCalibration from '../../../scripts/gamepadCalibration';
import Events from '../../../utils/events.ts';
import keyboardNavigation from 'scripts/keyboardNavigation';

export default function (view) {
    function submit(e) {
        appSettings.enableGamepad(view.querySelector('.chkEnableGamepad').checked);
        appSettings.enableSmoothScroll(view.querySelector('.chkSmoothScroll').checked);

        toast(globalize.translate('SettingsSaved'));

        Events.trigger(view, 'saved');

        e?.preventDefault();

        return false;
    }

    // The first currently-connected gamepad, or null if none is connected.
    function getConnectedGamepad() {
        const gamepads = navigator.getGamepads(); /* eslint-disable-line compat/compat */
        for (let i = 0; i < gamepads.length; i++) {
            if (gamepads[i]?.connected) {
                return gamepads[i];
            }
        }
        return null;
    }

    function setCalibrationStatus(text) {
        view.querySelector('.gamepadCalibrationStatus').textContent = text;
    }

    function setCalibratingUiState(isCalibrating) {
        view.querySelector('.btnCalibrateGamepad').classList.toggle('hide', isCalibrating);
        view.querySelector('.btnCancelCalibration').classList.toggle('hide', !isCalibrating);
    }

    // Show/hide the "Clear Calibration" button based on whether the
    // currently-connected gamepad actually has a saved custom mapping.
    function refreshClearButtonVisibility() {
        const gamepad = getConnectedGamepad();
        const hasMapping = !!(gamepad && appSettings.getGamepadMapping(gamepad.id));
        view.querySelector('.btnClearGamepadCalibration').classList.toggle('hide', !hasMapping);
    }

    function onCalibrationStep(step, stepIndex, totalSteps) {
        const label = globalize.translate(step.labelKey);
        setCalibrationStatus(`(${stepIndex + 1}/${totalSteps}) ${globalize.translate('GamepadCalibrationPressButton', label)}`);
    }

    function onCalibrationComplete(result) {
        const gamepad = getConnectedGamepad();
        setCalibratingUiState(false);

        if (!gamepad) {
            setCalibrationStatus(globalize.translate('GamepadCalibrationDisconnected'));
            return;
        }

        appSettings.setGamepadMapping(gamepad.id, result);
        setCalibrationStatus(globalize.translate('GamepadCalibrationComplete'));
        refreshClearButtonVisibility();
    }

    function onCalibrationCancel(reason) {
        setCalibratingUiState(false);

        if (reason === 'disconnected') {
            setCalibrationStatus(globalize.translate('GamepadCalibrationDisconnected'));
        } else {
            setCalibrationStatus(globalize.translate('GamepadCalibrationCancelled'));
        }
    }

    function onCalibrateClick() {
        const gamepad = getConnectedGamepad();

        if (!gamepad) {
            setCalibrationStatus(globalize.translate('GamepadCalibrationNoneConnected'));
            return;
        }

        setCalibratingUiState(true);
        gamepadCalibration.start(gamepad.index, onCalibrationStep, onCalibrationComplete, onCalibrationCancel);
    }

    function onCancelClick() {
        gamepadCalibration.cancel('cancelled');
    }

    function onClearClick() {
        const gamepad = getConnectedGamepad();
        if (!gamepad) {
            return;
        }

        appSettings.clearGamepadMapping(gamepad.id);
        setCalibrationStatus(globalize.translate('GamepadCalibrationCleared'));
        refreshClearButtonVisibility();
    }

    view.querySelector('.btnCalibrateGamepad').addEventListener('click', onCalibrateClick);
    view.querySelector('.btnCancelCalibration').addEventListener('click', onCancelClick);
    view.querySelector('.btnClearGamepadCalibration').addEventListener('click', onClearClick);

    view.addEventListener('viewshow', function () {
        const gamepadSupported = keyboardNavigation.canEnableGamepad();

        view.querySelector('.enableGamepadContainer').classList.toggle('hide', !gamepadSupported);
        view.querySelector('.smoothScrollContainer').classList.toggle('hide', !layoutManager.tv);
        view.querySelector('.gamepadCalibrationContainer').classList.toggle('hide', !gamepadSupported);

        view.querySelector('.chkEnableGamepad').checked = appSettings.enableGamepad();
        view.querySelector('.chkSmoothScroll').checked = appSettings.enableSmoothScroll();

        setCalibrationStatus('');
        setCalibratingUiState(false);
        refreshClearButtonVisibility();

        view.querySelector('form').addEventListener('submit', submit);
        view.querySelector('.btnSave').classList.remove('hide');

        import('../../../components/autoFocuser').then(({ default: autoFocuser }) => {
            autoFocuser.autoFocus(view);
        });
    });

    view.addEventListener('viewbeforehide', function () {
        gamepadCalibration.cancel('viewchange');
    });
}
