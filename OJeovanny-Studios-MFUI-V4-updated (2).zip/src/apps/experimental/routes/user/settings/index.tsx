import React, { useEffect, useMemo, useState, type FC } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import type { UserDto } from '@jellyfin/sdk/lib/generated-client/models/user-dto';

import { appHost } from 'components/apphost';
import Page from 'components/Page';
import { AppFeature } from 'constants/appFeature';
import { useApi } from 'hooks/useApi';
import { useQuickConnectEnabled } from 'hooks/useQuickConnect';
import { useUsers } from 'hooks/useUsers';
import globalize from 'lib/globalize';
import Dashboard from 'utils/dashboard';
import shell from 'scripts/shell';

import './settings.scss';

interface SettingsItem {
    key: string;
    icon: string;
    label: string;
    href?: string;
    onClick?: () => void;
    danger?: boolean;
}

const SettingsRow: FC<{ item: SettingsItem }> = ({ item }) => {
    const inner = (
        <div className={`oj-cfg-row${item.danger ? ' oj-cfg-row--danger' : ''}`}>
            <i className={`ti ${item.icon} oj-cfg-row-icon`} aria-hidden='true' />
            <span className='oj-cfg-row-label'>{item.label}</span>
            <i className='ti ti-chevron-right oj-cfg-row-arrow' aria-hidden='true' />
        </div>
    );

    if (item.href) {
        return <Link to={item.href} className='oj-cfg-row-wrap'>{inner}</Link>;
    }

    return (
        <button type='button' className='oj-cfg-row-wrap' onClick={item.onClick}>
            {inner}
        </button>
    );
};

const SettingsSection: FC<{ title: string; items: SettingsItem[] }> = ({ title, items }) => {
    if (!items.length) return null;

    return (
        <div className='oj-cfg-section'>
            <div className='oj-cfg-section-title'>{title}</div>
            <div className='oj-cfg-list'>
                {items.map(item => <SettingsRow key={item.key} item={item} />)}
            </div>
        </div>
    );
};

const UserSettingsPage: FC = () => {
    const navigate = useNavigate();
    const { user: currentUser } = useApi();
    const [searchParams] = useSearchParams();
    const { data: isQuickConnectEnabled } = useQuickConnectEnabled();
    const { data: users } = useUsers();
    const [user, setUser] = useState<UserDto>();

    const userId = useMemo(() => (
        searchParams.get('userId') || currentUser?.Id
    ), [currentUser, searchParams]);

    const isLoggedInUser = useMemo(() => (
        userId && userId === currentUser?.Id
    ), [currentUser, userId]);

    useEffect(() => {
        if (userId) {
            if (userId === currentUser?.Id) setUser(currentUser);
            else setUser(users?.find(({ Id }) => userId === Id));
        }
    }, [currentUser, userId, users]);

    const preferenceItems: SettingsItem[] = [
        {
            key: 'profile',
            icon: 'ti-user',
            label: globalize.translate('Profile'),
            href: `/userprofile?userId=${userId}`
        },
        {
            key: 'display',
            icon: 'ti-device-tv',
            label: globalize.translate('Display'),
            href: `/mypreferencesdisplay?userId=${userId}`
        },
        {
            key: 'playback',
            icon: 'ti-player-play',
            label: globalize.translate('TitlePlayback'),
            href: `/mypreferencesplayback?userId=${userId}`
        },
        {
            key: 'subtitles',
            icon: 'ti-subtask',
            label: globalize.translate('Subtitles'),
            href: `/mypreferencessubtitles?userId=${userId}`
        },
        ...(isQuickConnectEnabled ? [{
            key: 'quickconnect',
            icon: 'ti-link',
            label: globalize.translate('QuickConnect'),
            href: `/quickconnect?userId=${userId}`
        }] : [])
    ];

    const adminItems: SettingsItem[] = (isLoggedInUser && user?.Policy?.IsAdministrator) ? [
        {
            key: 'dashboard',
            icon: 'ti-layout-dashboard',
            label: globalize.translate('TabDashboard'),
            href: '/dashboard'
        },
        {
            key: 'metadata',
            icon: 'ti-edit',
            label: globalize.translate('MetadataManager'),
            href: '/metadata'
        }
    ] : [];

    const accountItems: SettingsItem[] = isLoggedInUser ? [
        ...(appHost.supports(AppFeature.MultiServer) ? [{
            key: 'server',
            icon: 'ti-server',
            label: globalize.translate('SelectServer'),
            onClick: Dashboard.selectServer
        }] : []),
        ...(appHost.supports(AppFeature.DownloadManagement) ? [{
            key: 'downloads',
            icon: 'ti-download',
            label: globalize.translate('DownloadManager'),
            onClick: shell.openDownloadManager
        }] : []),
        {
            key: 'logout',
            icon: 'ti-logout',
            label: globalize.translate('ButtonSignOut'),
            onClick: Dashboard.logout,
            danger: true
        }
    ] : [];

    const initials = user?.Name
        ? user.Name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2)
        : '?';

    return (
        <Page
            id='ojSettingsPage'
            title={globalize.translate('Settings')}
            className='mainAnimatedPage noSecondaryNavPage'
            shouldAutoFocus
        >
            <div className='oj-cfg-root'>
                {/* Header */}
                <div className='oj-cfg-header'>
                    <button
                        type='button'
                        className='oj-cfg-back'
                        onClick={() => navigate(-1)}
                        aria-label='Voltar'
                    >
                        <i className='ti ti-arrow-left' />
                    </button>
                    <div className='oj-cfg-logo'>
                        OJeovanny<span>Studios</span>
                    </div>
                </div>

                {/* User card */}
                {user && (
                    <div className='oj-cfg-user-card'>
                        <div className='oj-cfg-avatar'>{initials}</div>
                        <div className='oj-cfg-user-info'>
                            <div className='oj-cfg-user-name'>{user.Name}</div>
                            <div className='oj-cfg-user-role'>
                                {user.Policy?.IsAdministrator
                                    ? globalize.translate('HeaderAdmin')
                                    : globalize.translate('HeaderUser')}
                            </div>
                        </div>
                    </div>
                )}

                {/* Sections */}
                <div className='oj-cfg-body'>
                    <SettingsSection
                        title='Preferências'
                        items={preferenceItems}
                    />
                    {adminItems.length > 0 && (
                        <SettingsSection
                            title={globalize.translate('HeaderAdmin')}
                            items={adminItems}
                        />
                    )}
                    <SettingsSection
                        title={globalize.translate('HeaderUser')}
                        items={accountItems}
                    />
                </div>

                {/* Footer */}
                <div className='oj-cfg-footer'>
                    <Link to='/home2' className='oj-cfg-footer-link'>
                        <i className='ti ti-home' /> Voltar ao início
                    </Link>
                </div>
            </div>
        </Page>
    );
};

export default UserSettingsPage;
