import React, { type FC } from 'react';
import { useQuery } from '@tanstack/react-query';
import { getItemsApi } from '@jellyfin/sdk/lib/utils/api/items-api';
import { getUserLibraryApi } from '@jellyfin/sdk/lib/utils/api/user-library-api';
import { ItemFields } from '@jellyfin/sdk/lib/generated-client/models/item-fields';
import { ImageType } from '@jellyfin/sdk/lib/generated-client/models/image-type';
import type { BaseItemDto } from '@jellyfin/sdk/lib/generated-client/models/base-item-dto';

import Page from 'components/Page';
import { appRouter } from 'components/router/appRouter';
import { useApi } from 'hooks/useApi';
import { useUserViews } from 'hooks/useUserViews';

import HomeNav, { buildNavLinks } from './HomeNav';
import HomeHero from './HomeHero';
import ContinueWatchingRow from './ContinueWatchingRow';
import HomeRow, { type HomeCardItem } from './HomeRow';
import BottomNav from './BottomNav';
import './home2.scss';

const RESUME_ITEMS_LIMIT = 9;

const fetchResumeItems = async (
    api: ReturnType<typeof useApi>['api'],
    userId?: string
): Promise<BaseItemDto[]> => {
    if (!api || !userId) return [];

    const response = await getItemsApi(api).getResumeItems({
        userId,
        limit: RESUME_ITEMS_LIMIT,
        fields: [
            ItemFields.PrimaryImageAspectRatio,
            ItemFields.MediaSourceCount,
            ItemFields.Genres
        ],
        imageTypeLimit: 1,
        enableImageTypes: [
            ImageType.Primary,
            ImageType.Thumb,
            ImageType.Backdrop
        ],
        enableTotalRecordCount: false
    });

    return response.data.Items ?? [];
};

const fetchLatestMedia = async (
    api: ReturnType<typeof useApi>['api'],
    userId: string | undefined,
    firstLibraryId: string | undefined
): Promise<BaseItemDto[]> => {
    if (!api || !userId) return [];

    const response = await getUserLibraryApi(api).getLatestMedia({
        userId,
        parentId: firstLibraryId ?? undefined,
        limit: 1,
        fields: [
            ItemFields.PrimaryImageAspectRatio,
            ItemFields.MediaSourceCount,
            ItemFields.Genres,
            ItemFields.Overview
        ],
        imageTypeLimit: 1,
        enableImageTypes: [
            ImageType.Primary,
            ImageType.Thumb,
            ImageType.Backdrop
        ]
    });

    return response.data ?? [];
};

const LIBRARY_SHORTCUT_ICONS: Record<string, string> = {
    tvshows: 'ti-device-tv',
    movies: 'ti-movie',
    music: 'ti-music',
    playlists: 'ti-playlist',
    books: 'ti-book',
    homevideos: 'ti-video'
};

const buildLibraryCards = (views: BaseItemDto[] | undefined): HomeCardItem[] => {
    if (!views?.length) return [];

    return views.map(view => {
        const collectionType = view.CollectionType ?? undefined;

        return {
            key: view.Id ?? view.Name ?? Math.random().toString(36),
            item: view as never,
            title: view.Name ?? '',
            icon: (collectionType && LIBRARY_SHORTCUT_ICONS[collectionType]) ?? 'ti-folder',
            href: appRouter.getRouteUrl(view as never, { context: collectionType }).substring(1)
        };
    });
};

const Home2: FC = () => {
    const { api, user } = useApi();
    const { data: userViewsResult } = useUserViews(user?.Id);

    // useUserViews retorna BaseItemDtoQueryResult — extraímos o array .Items
    const userViews = userViewsResult?.Items ?? [];

    const { data: resumeItems = [] } = useQuery({
        queryKey: [ 'Home2', 'ResumeItems', user?.Id ],
        queryFn: () => fetchResumeItems(api, user?.Id),
        enabled: !!api && !!user?.Id,
        staleTime: 1000
    });

    const firstLibraryId = userViews[0]?.Id ?? undefined;

    const { data: latestMediaItems = [] } = useQuery({
        queryKey: [ 'Home2', 'LatestMedia', user?.Id, firstLibraryId ],
        queryFn: () => fetchLatestMedia(api, user?.Id, firstLibraryId),
        enabled: !!api && !!user?.Id && resumeItems.length === 0,
        staleTime: 1000
    });

    const navLinks = buildNavLinks(userViews as never[]);
    const libraryCards = buildLibraryCards(userViews);

    const heroItem = (resumeItems[0] ?? latestMediaItems[0]) as never;
    const continueWatchingItems = resumeItems as never[];

    return (
        <Page
            id='home2Page'
            className='mainAnimatedPage homePage libraryPage allLibraryPage backdropPage oj-root'
            isBackButtonEnabled={false}
            backDropType='movie,series,book'
        >
            <HomeNav navLinks={navLinks} />

            <HomeHero item={heroItem} />

            <ContinueWatchingRow
                title='Continuar assistindo'
                items={continueWatchingItems}
                getHref={(item) => appRouter.getRouteUrl(item as never, { context: (item as BaseItemDto).CollectionType ?? undefined }).substring(1)}
            />

            <HomeRow
                title='Minha biblioteca'
                cards={libraryCards}
            />

            <BottomNav navLinks={navLinks} />
        </Page>
    );
};

export default Home2;
