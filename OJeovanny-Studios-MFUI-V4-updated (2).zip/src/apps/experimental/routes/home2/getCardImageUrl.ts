import type { Api } from '@jellyfin/sdk';
import { ImageType } from '@jellyfin/sdk/lib/generated-client/models/image-type';
import { getImageApi } from '@jellyfin/sdk/lib/utils/api/image-api';

import type { ItemDto } from 'types/base/models/item-dto';

interface GetItemImageUrlOptions {
    fillWidth?: number;
    fillHeight?: number;
}

/**
 * Resolves a background image URL for an item, preferring the requested
 * imageType and falling back through the item's own images, then its
 * parent/series images (the way episodes inherit art from their show),
 * the way Jellyfin's own card builder does it.
 * Returns undefined when there is no usable image anywhere in the chain,
 * so the caller can fall back to the decorative gradient + item name
 * treatment used by the mockup.
 */
export function getItemImageUrl(
    api: Api | undefined,
    item: ItemDto,
    imageType: ImageType,
    options: GetItemImageUrlOptions = {}
): string | undefined {
    if (!api) return undefined;

    const imageApi = getImageApi(api);
    const fetchOptions = {
        fillWidth: options.fillWidth,
        fillHeight: options.fillHeight,
        quality: 90
    };

    // 1. The item's own requested image type (e.g. Thumb/Backdrop on the episode itself)
    if (item.Id && item.ImageTags?.[imageType]) {
        return imageApi.getItemImageUrlById(item.Id, imageType, fetchOptions);
    }

    // 2. The item's own Primary image (most episodes only have this — the screenshot)
    if (item.Id && item.ImageTags?.[ImageType.Primary]) {
        return imageApi.getItemImageUrlById(item.Id, ImageType.Primary, fetchOptions);
    }

    // 3. The item's own backdrop, if it has one
    if (item.Id && item.BackdropImageTags?.length) {
        return imageApi.getItemImageUrlById(item.Id, ImageType.Backdrop, fetchOptions);
    }

    // 4. Inherited thumb from the parent (series) — common for episodes
    if (item.ParentThumbItemId && item.ParentThumbImageTag) {
        return imageApi.getItemImageUrlById(item.ParentThumbItemId, ImageType.Thumb, fetchOptions);
    }

    // 5. Inherited backdrop from the parent (series)
    if (item.ParentBackdropItemId && item.ParentBackdropImageTags?.length) {
        return imageApi.getItemImageUrlById(item.ParentBackdropItemId, ImageType.Backdrop, fetchOptions);
    }

    // 6. Series primary image (poster) as a last resort before the gradient placeholder
    if (item.SeriesId && item.SeriesPrimaryImageTag) {
        return imageApi.getItemImageUrlById(item.SeriesId, ImageType.Primary, fetchOptions);
    }

    return undefined;
}

export { ImageType };
