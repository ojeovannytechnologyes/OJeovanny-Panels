import React, { type FC } from 'react';

import { useApi } from 'hooks/useApi';
import { ImageType } from '@jellyfin/sdk/lib/generated-client/models/image-type';

import type { ItemDto } from 'types/base/models/item-dto';
import { getItemImageUrl } from './getCardImageUrl';

interface ContinueWatchingRowProps {
    title: string;
    items: ItemDto[];
    getHref: (item: ItemDto) => string;
}

const buildEpisodeLabel = (item: ItemDto): string | undefined => {
    if (item.ParentIndexNumber != null && item.IndexNumber != null) {
        const epName = item.Name ?? '';
        return `S${item.ParentIndexNumber}:E${item.IndexNumber} · ${epName}`;
    }

    return item.ProductionYear ? String(item.ProductionYear) : undefined;
};

const ContinueWatchingRow: FC<ContinueWatchingRowProps> = ({ title, items, getHref }) => {
    const { api } = useApi();

    if (!items.length) return null;

    return (
        <div className='oj-section'>
            <div className='oj-section-header'>
                <div className='oj-section-title'>{title}</div>
                <div className='oj-section-line' />
            </div>
            <div className='oj-continue-cards'>
                {items.map(item => {
                    const bgUrl = getItemImageUrl(api, item, ImageType.Thumb, { fillWidth: 480, fillHeight: 270 });
                    const progressPercent = item.UserData?.PlayedPercentage ?? 0;
                    const displayTitle = item.SeriesName ?? item.Name ?? '';
                    const episodeLabel = buildEpisodeLabel(item);

                    return (
                        <a key={item.Id} className='oj-continue-card' href={`#/${getHref(item)}`}>
                            <div className='oj-continue-img'>
                                {bgUrl ? (
                                    <div
                                        style={{ width: '100%', height: '100%', backgroundImage: `url(${bgUrl})`, backgroundSize: 'cover', backgroundPosition: 'center' }}
                                    />
                                ) : (
                                    <div
                                        style={{
                                            width: '100%',
                                            height: '100%',
                                            background: 'linear-gradient(135deg,#1a1a2e,#0d0d1a)',
                                            display: 'flex',
                                            alignItems: 'center',
                                            justifyContent: 'center'
                                        }}
                                    >
                                        <span
                                            style={{
                                                fontFamily: "'Cormorant Garamond',serif",
                                                fontSize: '20px',
                                                fontWeight: 300,
                                                letterSpacing: '6px',
                                                color: 'rgba(255,255,255,0.15)',
                                                textTransform: 'uppercase'
                                            }}
                                        >
                                            {displayTitle}
                                        </span>
                                    </div>
                                )}
                                <div className='oj-card-overlay' />
                                <div className='oj-card-overlay-hover' />
                                <div className='oj-card-progress'>
                                    <div className='oj-card-progress-fill' style={{ width: `${progressPercent}%` }} />
                                </div>
                            </div>
                            <div className='oj-continue-info'>
                                <div className='oj-continue-title'>{displayTitle}</div>
                                {episodeLabel && (
                                    <div className='oj-continue-ep'>{episodeLabel}</div>
                                )}
                            </div>
                        </a>
                    );
                })}
            </div>
        </div>
    );
};

export default ContinueWatchingRow;
