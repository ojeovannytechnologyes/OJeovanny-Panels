import React, { type FC } from 'react';
import { Link } from 'react-router-dom';

import { appRouter } from 'components/router/appRouter';
import { useApi } from 'hooks/useApi';
import { ImageType } from '@jellyfin/sdk/lib/generated-client/models/image-type';

import type { ItemDto } from 'types/base/models/item-dto';
import { getItemImageUrl } from './getCardImageUrl';

export interface HomeCardItem {
    key: string;
    item?: ItemDto;
    title: string;
    subtitle?: string;
    icon?: string;
    href: string;
    progressPercent?: number;
}

interface HomeRowProps {
    title: string;
    cards: HomeCardItem[];
}

const HomeRow: FC<HomeRowProps> = ({ title, cards }) => {
    const { api } = useApi();

    return (
        <div className='oj-section'>
            <div className='oj-section-header'>
                <div className='oj-section-title'>{title}</div>
                <div className='oj-section-line' />
            </div>
            <div className='oj-cards'>
                {cards.map(card => {
                    const bgUrl = card.item
                        ? getItemImageUrl(api, card.item, ImageType.Primary, { fillWidth: 280, fillHeight: 420 })
                        : undefined;

                    return (
                        <Link key={card.key} className='oj-card' to={card.href.startsWith('/') ? card.href : `/${card.href}`}>
                            <div className='oj-card-img'>
                                {bgUrl ? (
                                    <div
                                        className='oj-card-bg'
                                        style={{ backgroundImage: `url(${bgUrl})` }}
                                    />
                                ) : (
                                    <div className='oj-card-bg'>
                                        {card.icon ? (
                                            <i className={`ti ${card.icon}`} aria-hidden='true' />
                                        ) : (
                                            <span>{card.title}</span>
                                        )}
                                    </div>
                                )}
                                <div className='oj-card-overlay' />
                                <div className='oj-card-overlay-hover' />
                                <div className='oj-card-info'>
                                    <div className='oj-card-title'>{card.title}</div>
                                    {card.subtitle && (
                                        <div className='oj-card-sub'>{card.subtitle}</div>
                                    )}
                                </div>
                                {typeof card.progressPercent === 'number' && (
                                    <div className='oj-card-progress'>
                                        <div
                                            className='oj-card-progress-fill'
                                            style={{ width: `${card.progressPercent}%` }}
                                        />
                                    </div>
                                )}
                            </div>
                        </Link>
                    );
                })}
            </div>
        </div>
    );
};

export const itemToHomeCard = (item: ItemDto): HomeCardItem => ({
    key: item.Id ?? item.Name ?? Math.random().toString(36),
    item,
    title: item.Name ?? '',
    subtitle: item.ProductionYear ? String(item.ProductionYear) : undefined,
    href: appRouter.getRouteUrl(item, { context: item.CollectionType ?? undefined }).substring(1),
    progressPercent: item.UserData?.PlayedPercentage ?? undefined
});

export default HomeRow;
