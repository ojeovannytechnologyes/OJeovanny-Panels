import React, { type FC, useEffect, useMemo, useRef } from 'react';

import { appRouter } from 'components/router/appRouter';
import { playbackManager } from 'components/playback/playbackmanager';
import { useApi } from 'hooks/useApi';
import { useToggleFavoriteMutation } from 'hooks/useFetchItems';
import globalize from 'lib/globalize';
import { ImageType } from '@jellyfin/sdk/lib/generated-client/models/image-type';

import type { ItemDto } from 'types/base/models/item-dto';
import { getItemImageUrl } from './getCardImageUrl';

interface HomeHeroProps {
    item?: ItemDto;
}

interface StarStyle {
    key: number;
    style: React.CSSProperties;
}

const STAR_COUNT = 80;

const buildMetaTags = (item: ItemDto): string[] => {
    const tags: string[] = [];

    if (item.ParentIndexNumber != null && item.IndexNumber != null) {
        tags.push(`S${item.ParentIndexNumber} · E${item.IndexNumber}`);
    }

    if (item.Genres?.length) {
        tags.push(item.Genres[0]);
    }

    if (item.ProductionYear) {
        tags.push(String(item.ProductionYear));
    }

    if (item.RunTimeTicks) {
        const minutes = Math.round(item.RunTimeTicks / 600000000);
        if (minutes > 0) tags.push(`${minutes} min`);
    }

    return tags;
};

const HomeHero: FC<HomeHeroProps> = ({ item }) => {
    const { api } = useApi();
    const starsRef = useRef<HTMLDivElement>(null);
    const toggleFavoriteMutation = useToggleFavoriteMutation();

    const prefersReducedMotion = useMemo(
        () => typeof window !== 'undefined'
            && window.matchMedia?.('(prefers-reduced-motion: reduce)').matches,
        []
    );

    const stars = useMemo<StarStyle[]>(() => {
        if (prefersReducedMotion) return [];

        return Array.from({ length: STAR_COUNT }, (_, i) => {
            const size = Math.random() * 1.5 + 0.5;
            return {
                key: i,
                style: {
                    width: `${size}px`,
                    height: `${size}px`,
                    top: `${Math.random() * 100}%`,
                    left: `${Math.random() * 100}%`,
                    opacity: Math.random() * 0.4 + 0.05
                }
            };
        });
    }, [ prefersReducedMotion ]);

    useEffect(() => {
        // Decorative only — particles are generated client-side and carry no real data.
    }, []);

    if (!item) return null;

    const bgUrl = getItemImageUrl(api, item, ImageType.Backdrop, { fillWidth: 1920, fillHeight: 1080 });
    const metaTags = buildMetaTags(item);
    const progressPercent = item.UserData?.PlayedPercentage ?? 0;
    const isFavorite = !!item.UserData?.IsFavorite;
    const detailsUrl = appRouter.getRouteUrl(item, { context: item.CollectionType ?? undefined }).substring(1);

    const onPlayClick = () => {
        playbackManager.play({
            items: [ item ],
            startPositionTicks: item.UserData?.PlaybackPositionTicks ?? 0
        });
    };

    const onFavoriteClick = () => {
        if (!item.Id) return;
        toggleFavoriteMutation.mutate({ itemId: item.Id, isFavorite });
    };

    return (
        <div className='oj-hero'>
            <div
                className='oj-hero-bg'
                style={bgUrl ? { backgroundImage: `url(${bgUrl})` } : undefined}
            />
            <div className='oj-hero-stars' ref={starsRef}>
                {stars.map(star => (
                    <div key={star.key} className='star' style={star.style} />
                ))}
            </div>
            <div className='oj-hero-overlay' />
            <div className='oj-hero-content'>
                <div className='oj-featured-label'>Em destaque</div>
                <div className='oj-featured-title'>{item.Name}</div>
                {metaTags.length > 0 && (
                    <div className='oj-featured-meta'>
                        {metaTags.map((tag, idx) => (
                            <React.Fragment key={tag}>
                                {idx > 0 && <div className='oj-meta-dot' />}
                                <span className='oj-meta-tag'>{tag}</span>
                            </React.Fragment>
                        ))}
                    </div>
                )}
                <div className='oj-hero-actions'>
                    <button className='oj-btn-play' type='button' onClick={onPlayClick}>
                        <i className='ti ti-player-play' aria-hidden='true' /> {globalize.translate('Play')}
                    </button>
                    <a className='oj-btn-ghost' href={`#/${detailsUrl}`}>
                        <i className='ti ti-info-circle' aria-hidden='true' /> Detalhes
                    </a>
                    <button
                        className='oj-btn-ghost'
                        type='button'
                        aria-label={globalize.translate('Favorites')}
                        aria-pressed={isFavorite}
                        onClick={onFavoriteClick}
                    >
                        <i className={`ti ti-heart${isFavorite ? '-filled' : ''}`} aria-hidden='true' />
                    </button>
                </div>
            </div>
            <div className='oj-progress-bar'>
                <div className='oj-progress-fill' style={{ width: `${progressPercent}%` }} />
            </div>
        </div>
    );
};

export default HomeHero;
