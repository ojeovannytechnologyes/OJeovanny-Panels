import React, { type FC, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useDebounceValue } from 'usehooks-ts';

import Page from 'components/Page';
import { appRouter } from 'components/router/appRouter';
import { useApi } from 'hooks/useApi';
import useSearchParam from 'hooks/useSearchParam';
import { useSearchItems } from 'apps/stable/features/search/api/useSearchItems';
import { useSearchSuggestions } from 'apps/stable/features/search/api/useSearchSuggestions';
import { getItemImageUrl } from '../home2/getCardImageUrl';
import { ImageType } from '@jellyfin/sdk/lib/generated-client/models/image-type';
import type { BaseItemDto } from '@jellyfin/sdk/lib/generated-client/models/base-item-dto';

import './search.scss';

const QUERY_PARAM = 'query';

/* ── Result card ─────────────────────────────────────────────── */
const ResultCard: FC<{ item: BaseItemDto }> = ({ item }) => {
    const { api } = useApi();
    const bgUrl = getItemImageUrl(api, item as never, ImageType.Primary, { fillWidth: 280, fillHeight: 420 });
    const href = appRouter.getRouteUrl(item as never).replace(/^#\//, '');

    return (
        <Link className='oj-s-card' to={`/${href}`}>
            <div className='oj-s-card-img'>
                {bgUrl
                    ? <div className='oj-s-card-bg' style={{ backgroundImage: `url(${bgUrl})` }} />
                    : <div className='oj-s-card-bg oj-s-card-bg--empty'><i className='ti ti-photo' /></div>
                }
                <div className='oj-s-card-overlay' />
            </div>
            <div className='oj-s-card-title'>{item.Name}</div>
            {item.ProductionYear && (
                <div className='oj-s-card-year'>{item.ProductionYear}</div>
            )}
        </Link>
    );
};

/* ── Results grid ────────────────────────────────────────────── */
const Results: FC<{ query: string }> = ({ query }) => {
    const { data, isPending } = useSearchItems(undefined, undefined, query.trim());

    if (isPending) {
        return (
            <div className='oj-s-loading'>
                <div className='oj-s-spinner' />
            </div>
        );
    }

    const allItems = (data ?? []).flatMap(section => section.items ?? []);

    if (!allItems.length) {
        return (
            <div className='oj-s-empty'>
                <i className='ti ti-search-off' />
                <p>Nenhum resultado para <em>"{query}"</em></p>
            </div>
        );
    }

    return (
        <div className='oj-s-grid'>
            {allItems.map(item => (
                <ResultCard key={item.Id} item={item} />
            ))}
        </div>
    );
};

/* ── Suggestions ─────────────────────────────────────────────── */
const Suggestions: FC<{ onSelect: (name: string) => void }> = ({ onSelect }) => {
    const { data: suggestions, isPending } = useSearchSuggestions();

    if (isPending || !suggestions?.length) return null;

    return (
        <div className='oj-s-suggestions'>
            <div className='oj-s-suggestions-label'>Sugestões</div>
            <div className='oj-s-suggestions-list'>
                {suggestions.map(item => (
                    <button
                        key={item.Id}
                        type='button'
                        className='oj-s-suggestion'
                        onClick={() => onSelect(item.Name ?? '')}
                    >
                        {item.Name}
                    </button>
                ))}
            </div>
        </div>
    );
};

/* ── Page ────────────────────────────────────────────────────── */
const SearchPage: FC = () => {
    const navigate = useNavigate();
    const inputRef = useRef<HTMLInputElement>(null);
    const [query, setQuery] = useSearchParam(QUERY_PARAM);
    const [debouncedQuery] = useDebounceValue(query, 400);

    return (
        <Page
            id='ojSearchPage'
            title='Buscar'
            className='mainAnimatedPage noSecondaryNavPage'
        >
            <div className='oj-s-root'>
                {/* Header */}
                <div className='oj-s-header'>
                    <button
                        type='button'
                        className='oj-s-back'
                        onClick={() => navigate(-1)}
                        aria-label='Voltar'
                    >
                        <i className='ti ti-arrow-left' />
                    </button>
                    <div className='oj-s-logo'>
                        OJeovanny<span>Studios</span>
                    </div>
                </div>

                {/* Search bar */}
                <div className='oj-s-bar-wrap'>
                    <div className='oj-s-bar'>
                        <i className='ti ti-search oj-s-bar-icon' />
                        <input
                            ref={inputRef}
                            type='search'
                            className='oj-s-input'
                            placeholder='Buscar filmes, séries...'
                            value={query ?? ''}
                            autoFocus
                            onChange={e => setQuery(e.target.value)}
                        />
                        {query && (
                            <button
                                type='button'
                                className='oj-s-clear'
                                aria-label='Limpar'
                                onClick={() => { setQuery(''); inputRef.current?.focus(); }}
                            >
                                <i className='ti ti-x' />
                            </button>
                        )}
                    </div>
                </div>

                {/* Content */}
                <div className='oj-s-content'>
                    {debouncedQuery
                        ? <Results query={debouncedQuery} />
                        : <Suggestions onSelect={name => setQuery(name)} />
                    }
                </div>

                {/* Back link */}
                <div className='oj-s-footer'>
                    <Link to='/home2' className='oj-s-footer-link'>
                        <i className='ti ti-home' /> Voltar ao início
                    </Link>
                </div>
            </div>
        </Page>
    );
};

export default SearchPage;
