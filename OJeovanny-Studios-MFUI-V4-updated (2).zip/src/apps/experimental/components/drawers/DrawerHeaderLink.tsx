import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import React from 'react';

import { useSystemInfo } from 'hooks/useSystemInfo';
import ListItemLink from 'components/ListItemLink';

const DrawerHeaderLink = () => {
    const { data: systemInfo } = useSystemInfo();

    return (
        <ListItemLink to='/' className='oj-drawer-logo'>
            <ListItemIcon sx={{ minWidth: 'auto' }}>
                <span className='oj-drawer-logo-mark'>O</span>
            </ListItemIcon>
            <ListItemText
                className='oj-drawer-logo-text'
                primary={(
                    <>
                        {systemInfo?.ServerName || 'OJeovanny'}
                        <span>Studios</span>
                    </>
                )}
                slotProps={{
                    primary: { component: 'div' }
                }}
            />
        </ListItemLink>);
};

export default DrawerHeaderLink;
