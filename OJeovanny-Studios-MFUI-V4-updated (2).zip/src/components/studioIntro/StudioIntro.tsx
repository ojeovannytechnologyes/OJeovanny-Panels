import React, { useEffect, useRef, type FC } from 'react';

import './studioIntro.scss';

/**
 * Cinematic "studio ident" that plays once before video playback starts,
 * similar to the warp-speed logo animations used by Universal/Warner/etc.
 *
 * Implemented entirely with <canvas> so it has zero external asset
 * dependencies (no images/video files needed) - it can run the moment the
 * video route mounts, while the real video loads underneath it.
 *
 * Originally authored as a standalone HTML/JS prototype; ported here almost
 * verbatim and wrapped in a React lifecycle. The animation timeline is
 * compressed via TIME_SCALE so the whole ident takes ~4.5s instead of the
 * original ~10.8s, which feels snappier in the context of "press play and
 * watch something" rather than a stand-alone showreel.
 */

export interface StudioIntroProps {
    /** App / studio name shown in the center of the ident. */
    name?: string;
    /** Small subtitle shown beneath the name. */
    tagline?: string;
    /** Called once the ident has finished (or been skipped). */
    onComplete: () => void;
}

// Compresses the original ~10800ms timeline down to ~4500ms.
const TIME_SCALE = 2.4;
// Hard stop, in *real* ms (unscaled), as a safety net.
const TOTAL_DURATION_MS = 10800 / TIME_SCALE;

const StudioIntro: FC<StudioIntroProps> = ({
    name = 'OJeovanny Studios',
    tagline = 'Where Stories Come to Life',
    onComplete
}) => {
    const stageRef = useRef<HTMLDivElement>(null);
    const nameRef = useRef<HTMLDivElement>(null);
    const taglineRef = useRef<HTMLDivElement>(null);
    const canvasRefs = [
        useRef<HTMLCanvasElement>(null),
        useRef<HTMLCanvasElement>(null),
        useRef<HTMLCanvasElement>(null),
        useRef<HTMLCanvasElement>(null)
    ];
    /** Guards against onComplete firing twice (timeout race + skip click). */
    const completedRef = useRef(false);

    useEffect(() => {
        const stage = stageRef.current;
        const nameEl = nameRef.current;
        const taglineEl = taglineRef.current;
        const canvases = canvasRefs.map(r => r.current);

        if (!stage || !nameEl || !taglineEl || canvases.some(c => !c)) return;

        const contexts = canvases.map(c => c!.getContext('2d')!);
        const [ x0, x1, x2, x3 ] = contexts;

        let W = 0, H = 0, T0 = 0, frameN = 0, raf = 0;

        const cl = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));
        const eo = (t: number, p = 3) => 1 - Math.pow(1 - cl(t, 0, 1), p);
        const es = (t: number) => 0.5 - 0.5 * Math.cos(cl(t, 0, 1) * Math.PI);
        const lp = (a: number, b: number, t: number) => a + (b - a) * t;

        // ── WARP STARS
        interface WarpStar {
            angle: number;
            d: number;
            speed: number;
            size: number;
            bright: number;
            tail: number;
            born: number;
        }
        let warpStars: WarpStar[] = [];
        const makeWarpStar = (forceClose?: boolean): WarpStar => {
            const angle = Math.random() * Math.PI * 2;
            const startD = forceClose ? Math.random() * 0.02 : Math.random() * 0.08;
            return {
                angle,
                d: startD,
                speed: Math.random() * 0.012 + 0.004,
                size: Math.random() * 1.8 + 0.4,
                bright: Math.random() * 0.7 + 0.3,
                tail: 0,
                born: Math.random() * 0.6
            };
        };
        const initWarp = () => {
            warpStars = [];
            for (let i = 0; i < 350; i++) warpStars.push(makeWarpStar());
        };

        // ── ORBITAL RINGS
        const ringDefs = [
            { r: 0.22, speed: 0.0004, dashes: 24, w: 0.7, op: 0.55, tickLen: 6 },
            { r: 0.32, speed: -0.0003, dashes: 48, w: 0.5, op: 0.35, tickLen: 4 },
            { r: 0.40, speed: 0.00015, dashes: 8, w: 0.9, op: 0.65, tickLen: 10 }
        ];
        let ringPhases = [ 0, 0, 0 ];
        const orbitDots: { ring: number; angle: number; speed: number; sz: number; ph: number; freq: number }[] = [];
        for (let i = 0; i < 6; i++) {
            orbitDots.push({
                ring: i % 3,
                angle: Math.random() * Math.PI * 2,
                speed: ringDefs[i % 3].speed * (1 + (Math.random() - 0.5) * 0.4) * (Math.random() < 0.5 ? 1 : -1),
                sz: Math.random() * 2.5 + 1.2,
                ph: Math.random() * Math.PI * 2,
                freq: 0.02 + Math.random() * 0.01
            });
        }

        const warpSpeed = (e: number) => {
            if (e < 1500) return eo(e / 1500, 2) * 1.0;
            if (e < 3200) return 1.0;
            if (e < 5000) return lp(1.0, 0.0, eo((e - 3200) / 1800, 2));
            return 0;
        };
        const warpIntensity = (e: number) => {
            if (e < 5200) return cl((e < 200 ? 0 : 1), 0, 1);
            return eo(1 - cl((e - 5200) / 600, 0, 1));
        };

        const drawBg = (e: number) => {
            if (e < 80) {
                const f = 1 - e / 80;
                x0.fillStyle = `rgb(${Math.round(f * 10)},${Math.round(f * 10)},${Math.round(f * 10)})`;
            } else {
                x0.fillStyle = '#000';
            }
            x0.fillRect(0, 0, W, H);

            const wi = warpIntensity(e);
            const vr = lp(0.85, 0.7, wi);
            const vig = x0.createRadialGradient(W / 2, H / 2, H * 0.02, W / 2, H / 2, H * vr);
            vig.addColorStop(0, 'rgba(0,0,0,0)');
            vig.addColorStop(1, `rgba(0,0,0,${lp(0.88, 0.96, wi)})`);
            x0.fillStyle = vig;
            x0.fillRect(0, 0, W, H);

            if (e > 4200) {
                const t = eo(cl((e - 4200) / 1800, 0, 1));
                const ft = e > 9500 ? eo(1 - cl((e - 9500) / 700, 0, 1)) : 1;
                const bl = x0.createRadialGradient(W / 2, H / 2, 0, W / 2, H / 2, Math.min(W, H) * 0.3);
                bl.addColorStop(0, `rgba(166,77,255,${0.09 * t * ft})`);
                bl.addColorStop(0.5, `rgba(166,77,255,${0.03 * t * ft})`);
                bl.addColorStop(1, 'rgba(0,0,0,0)');
                x0.fillStyle = bl;
                x0.fillRect(0, 0, W, H);
            }

            const bh = H * 0.048;
            x0.fillStyle = '#000';
            x0.fillRect(0, 0, W, bh);
            x0.fillRect(0, H - bh, W, bh);

            for (let i = 0; i < 600; i++) {
                x0.fillStyle = `rgba(255,255,255,${Math.random() * 0.045})`;
                x0.fillRect(Math.random() * W, Math.random() * H, 1, 1);
            }

            const sl = (frameN * 0.65) % (H - H * 0.096) + H * 0.048;
            x0.save();
            x0.globalAlpha = 0.022;
            x0.fillStyle = '#fff';
            x0.fillRect(0, sl, W, 1.2);
            x0.restore();
        };

        const drawWarp = (e: number) => {
            x1.clearRect(0, 0, W, H);
            if (e < 50) return;

            const spd = warpSpeed(e);
            const cx = W / 2, cy = H / 2;
            const maxR = Math.sqrt(W * W + H * H) * 0.52;

            warpStars.forEach(s => {
                if (e / 10000 < s.born && spd < 0.3) return;

                const vel = s.speed * (0.5 + spd * 2.5);
                s.d += vel;
                const tailLen = vel * lp(2, 28, spd);
                s.tail = tailLen;

                if (s.d > 1.05) {
                    Object.assign(s, makeWarpStar(true));
                    s.born = 0;
                    return;
                }

                const r = s.d * maxR;
                const rPrev = Math.max(0, (s.d - tailLen * 0.001 * maxR) * maxR);

                const x_ = cx + Math.cos(s.angle) * r;
                const y_ = cy + Math.sin(s.angle) * r;
                const xp = cx + Math.cos(s.angle) * rPrev;
                const yp = cy + Math.sin(s.angle) * rPrev;

                const brightness = s.bright * cl(spd * 2 + 0.2, 0.1, 1.0);
                const alpha = brightness * cl((s.d - 0.01) * 8, 0, 1);
                if (alpha < 0.02) return;

                x1.save();
                x1.globalAlpha = alpha;
                const grad = x1.createLinearGradient(xp, yp, x_, y_);
                grad.addColorStop(0, 'rgba(166,77,255,0)');
                grad.addColorStop(1, 'rgba(255,255,255,1)');
                x1.strokeStyle = grad;
                x1.lineWidth = s.size * cl(0.3 + spd * 1.5, 0.3, 2.2);
                x1.beginPath();
                x1.moveTo(xp, yp);
                x1.lineTo(x_, y_);
                x1.stroke();

                x1.globalAlpha = alpha * 0.9;
                const glow = x1.createRadialGradient(x_, y_, 0, x_, y_, s.size * 2);
                glow.addColorStop(0, 'rgba(255,255,255,0.9)');
                glow.addColorStop(1, 'rgba(255,255,255,0)');
                x1.fillStyle = glow;
                x1.beginPath();
                x1.arc(x_, y_, s.size * 2, 0, Math.PI * 2);
                x1.fill();
                x1.restore();
            });

            if (spd > 0.3) {
                const numRings = 4;
                for (let i = 0; i < numRings; i++) {
                    const phase = (frameN * 0.018 + i / numRings) % 1;
                    const r = phase * maxR * 0.85;
                    const a = 0.08 * (1 - phase) * spd;
                    x1.save();
                    x1.globalAlpha = a;
                    x1.strokeStyle = 'rgba(166,77,255,0.6)';
                    x1.lineWidth = lp(2.5, 0.5, phase);
                    x1.beginPath();
                    x1.arc(cx, cy, r, 0, Math.PI * 2);
                    x1.stroke();
                    x1.restore();
                }
            }
        };

        const drawLogo = (e: number) => {
            x2.clearRect(0, 0, W, H);
            if (e < 5000) return;

            const cx = W / 2, cy = H / 2;
            const S = Math.min(W, H);
            const R = S * 0.14;
            const ft = e > 9500 ? eo(1 - cl((e - 9500) / 700, 0, 1)) : 1;

            const t = eo(cl((e - 5000) / 1200, 0, 1), 4);
            x2.save();
            x2.globalAlpha = 0.18 * t * ft;
            x2.strokeStyle = '#fff';
            x2.lineWidth = 0.7;
            x2.beginPath();
            x2.arc(cx, cy, R * 1.18, 0, Math.PI * 2);
            x2.stroke();
            x2.restore();

            const sweep = eo(cl((e - 5000) / 900, 0, 1), 4) * Math.PI * 2;
            x2.save();
            x2.globalAlpha = 0.85 * ft;
            x2.strokeStyle = '#a64dff';
            x2.lineWidth = 1.5;
            x2.beginPath();
            x2.arc(cx, cy, R * 1.08, -Math.PI / 2, -Math.PI / 2 + sweep);
            x2.stroke();
            x2.restore();

            if (e > 5500) {
                const tt = eo(cl((e - 5500) / 600, 0, 1));
                for (let i = 0; i < 48; i++) {
                    if (i / 48 > tt) break;
                    const a = (i / 48) * Math.PI * 2 - Math.PI / 2;
                    const isMaj = (i % 12 === 0);
                    const r0 = isMaj ? R * 0.98 : R * 1.02, r1 = R * 1.08;
                    x2.save();
                    x2.globalAlpha = (isMaj ? 0.6 : 0.25) * ft;
                    x2.strokeStyle = '#fff';
                    x2.lineWidth = isMaj ? 1.2 : 0.6;
                    x2.beginPath();
                    x2.moveTo(cx + Math.cos(a) * r0, cy + Math.sin(a) * r0);
                    x2.lineTo(cx + Math.cos(a) * r1, cy + Math.sin(a) * r1);
                    x2.stroke();
                    x2.restore();
                }
                if (tt > 0.9) {
                    const dt = eo(cl((tt - 0.9) / 0.1, 0, 1));
                    ([
                        [ cx, cy - R * 1.18 ], [ cx, cy + R * 1.18 ], [ cx - R * 1.18, cy ], [ cx + R * 1.18, cy ]
                    ] as [number, number][]).forEach(([ px, py ]) => {
                        const sz = S * 0.006 * dt;
                        x2.save();
                        x2.globalAlpha = 0.65 * dt * ft;
                        x2.fillStyle = '#ff2ee6';
                        x2.beginPath();
                        x2.moveTo(px, py - sz * 2.2);
                        x2.lineTo(px + sz, py);
                        x2.lineTo(px, py + sz * 2.2);
                        x2.lineTo(px - sz, py);
                        x2.closePath();
                        x2.fill();
                        x2.restore();
                    });
                }
            }

            if (e > 5800) {
                const it = eo(cl((e - 5800) / 500, 0, 1));
                x2.save();
                x2.globalAlpha = 0.12 * it * ft;
                x2.strokeStyle = '#fff';
                x2.lineWidth = 0.5;
                x2.beginPath();
                x2.arc(cx, cy, R * 0.88, 0, Math.PI * 2);
                x2.stroke();
                x2.restore();
            }

            if (e > 5200) {
                const ot = eo(cl((e - 5200) / 900, 0, 1), 4);
                const blur = lp(14, 0, ot);
                const glowAmt = lp(0, R * 0.18, eo(cl((e - 5200) / 500, 0, 1)));
                const glowFade = e > 7000 ? lp(R * 0.18, R * 0.06, eo(cl((e - 7000) / 1500, 0, 1))) : glowAmt;
                const fs = R * 1.62;
                x2.save();
                x2.globalAlpha = ot * ft;
                x2.filter = `blur(${blur}px)`;
                x2.font = `300 ${fs}px 'Cormorant Garamond','Playfair Display',Georgia,serif`;
                x2.textAlign = 'center';
                x2.textBaseline = 'middle';
                x2.shadowColor = 'rgba(166,77,255,0.8)';
                x2.shadowBlur = glowFade;
                x2.strokeStyle = '#fff';
                x2.lineWidth = 1.5;
                x2.strokeText('O', cx - R * 0.28, cy + R * 0.05);
                x2.restore();

                if (e > 5600) {
                    const jt = eo(cl((e - 5600) / 800, 0, 1), 4);
                    const jBlur = lp(10, 0, jt);
                    x2.save();
                    x2.globalAlpha = jt * ft;
                    x2.filter = `blur(${jBlur}px)`;
                    x2.font = `300 ${R * 1.3}px 'Cormorant Garamond','Playfair Display',Georgia,serif`;
                    x2.textAlign = 'center';
                    x2.textBaseline = 'middle';
                    x2.shadowColor = 'rgba(255,46,230,0.7)';
                    x2.shadowBlur = glowFade;
                    x2.strokeStyle = '#fff';
                    x2.lineWidth = 1.2;
                    x2.strokeText('J', cx + R * 0.35, cy + R * 0.04);
                    x2.restore();
                }
            }
        };

        const drawOrbitals = (e: number) => {
            x3.clearRect(0, 0, W, H);
            if (e < 6200) return;
            const t = eo(cl((e - 6200) / 900, 0, 1));
            const ft = e > 9200 ? eo(1 - cl((e - 9200) / 900, 0, 1)) : 1;
            const cx = W / 2, cy = H / 2, S = Math.min(W, H);

            ringPhases = [ ringPhases[0] + 0.0004, ringPhases[1] - 0.0003, ringPhases[2] + 0.00015 ];

            ringDefs.forEach((rd, ri) => {
                const r = S * rd.r;
                const circ = 2 * Math.PI * r;
                const dashL = circ / rd.dashes * 0.45, gapL = circ / rd.dashes * 0.55;
                x3.save();
                x3.globalAlpha = rd.op * t * ft;
                x3.strokeStyle = '#fff';
                x3.lineWidth = rd.w;
                x3.setLineDash([ dashL, gapL ]);
                x3.lineDashOffset = -ringPhases[ri] * r * 100;
                x3.beginPath();
                x3.arc(cx, cy, r, 0, Math.PI * 2);
                x3.stroke();
                x3.setLineDash([]);
                x3.restore();

                const tc = rd.dashes * 2;
                for (let i = 0; i < tc; i++) {
                    const a = (i / tc) * Math.PI * 2 + ringPhases[ri];
                    const isMaj = (i % (tc / 4) === 0);
                    if (!isMaj && i % 6 !== 0) continue;
                    x3.save();
                    x3.globalAlpha = (isMaj ? 0.55 : 0.18) * t * ft;
                    x3.strokeStyle = '#fff';
                    x3.lineWidth = isMaj ? 0.9 : 0.4;
                    x3.beginPath();
                    x3.moveTo(cx + Math.cos(a) * (r - rd.tickLen * 0.5), cy + Math.sin(a) * (r - rd.tickLen * 0.5));
                    x3.lineTo(cx + Math.cos(a) * (r + rd.tickLen * 0.5), cy + Math.sin(a) * (r + rd.tickLen * 0.5));
                    x3.stroke();
                    x3.restore();
                }
            });

            orbitDots.forEach(od => {
                od.angle += od.speed;
                od.ph += od.freq;
                const r = S * ringDefs[od.ring].r;
                const px = cx + Math.cos(od.angle) * r, py = cy + Math.sin(od.angle) * r;
                const pulse = 0.6 + 0.4 * Math.sin(od.ph);
                const a = 0.85 * t * ft * pulse;
                x3.save();
                x3.globalAlpha = a;
                const dg = x3.createRadialGradient(px, py, 0, px, py, od.sz * 3);
                dg.addColorStop(0, 'rgba(255,255,255,0.95)');
                dg.addColorStop(1, 'rgba(255,255,255,0)');
                x3.fillStyle = dg;
                x3.beginPath();
                x3.arc(px, py, od.sz * 3, 0, Math.PI * 2);
                x3.fill();
                x3.globalAlpha = a * 0.9;
                x3.fillStyle = '#fff';
                x3.beginPath();
                x3.arc(px, py, od.sz * 0.6, 0, Math.PI * 2);
                x3.fill();
                x3.restore();
            });

            if (e > 7000) {
                const rt = eo(cl((e - 7000) / 600, 0, 1));
                const rft = e > 9000 ? eo(1 - cl((e - 9000) / 800, 0, 1)) : 1;
                for (let i = 0; i < 4; i++) {
                    const a = (i / 4) * Math.PI;
                    const len = Math.max(W, H) * 0.52;
                    const fw = Math.max(W, H) * 0.016;
                    const pulse = 0.6 + 0.4 * Math.sin(frameN * 0.018 + i);
                    x3.save();
                    x3.globalAlpha = 0.05 * rt * rft * pulse;
                    x3.translate(cx, cy);
                    x3.rotate(a);
                    const rg = x3.createLinearGradient(0, 0, len, 0);
                    rg.addColorStop(0, 'rgba(166,77,255,0.9)');
                    rg.addColorStop(1, 'rgba(255,255,255,0)');
                    x3.beginPath();
                    x3.moveTo(0, -fw);
                    x3.lineTo(len, -fw * 0.1);
                    x3.lineTo(len, fw * 0.1);
                    x3.lineTo(0, fw);
                    x3.closePath();
                    x3.fillStyle = rg;
                    x3.fill();
                    x3.restore();
                    x3.save();
                    x3.globalAlpha = 0.04 * rt * rft * pulse;
                    x3.translate(cx, cy);
                    x3.rotate(a + Math.PI);
                    x3.beginPath();
                    x3.moveTo(0, -fw * 0.6);
                    x3.lineTo(len, -fw * 0.08);
                    x3.lineTo(len, fw * 0.08);
                    x3.lineTo(0, fw * 0.6);
                    x3.closePath();
                    x3.fillStyle = rg;
                    x3.fill();
                    x3.restore();
                }
            }
        };

        const animUI = (e: number) => {
            const ft = e > 9500 ? eo(1 - cl((e - 9500) / 700, 0, 1)) : 1;
            if (e < 6800) {
                nameEl.style.opacity = '0';
            } else {
                const t = eo(cl((e - 6800) / 900, 0, 1));
                const ls = lp(window.innerWidth > 600 ? 22 : 12, window.innerWidth > 600 ? 16 : 8, t);
                nameEl.style.opacity = String(t * ft);
                nameEl.style.letterSpacing = `${ls}px`;
                nameEl.style.textShadow = `0 0 ${lp(20, 3, t)}px rgba(166,77,255,${lp(0.6, 0.2, t)})`;
            }
            if (e < 8000) {
                taglineEl.style.opacity = '0';
            } else {
                const t = es(cl((e - 8000) / 700, 0, 1));
                taglineEl.style.opacity = String(t * ft);
            }
        };

        const finish = () => {
            if (completedRef.current) return;
            completedRef.current = true;
            if (raf) cancelAnimationFrame(raf);
            onComplete();
        };

        const tick = (ts: number) => {
            if (!T0) T0 = ts;
            // Scale elapsed time so the whole sequence is shorter.
            const e = (ts - T0) * TIME_SCALE;
            frameN++;
            drawBg(e);
            drawWarp(e);
            drawLogo(e);
            drawOrbitals(e);
            animUI(e);
            if (e < 10800) {
                raf = requestAnimationFrame(tick);
            } else {
                finish();
            }
        };

        const resize = () => {
            W = stage.offsetWidth;
            H = stage.offsetHeight;
            canvases.forEach(c => {
                c!.width = W;
                c!.height = H;
            });
        };

        resize();
        initWarp();
        raf = requestAnimationFrame(tick);

        const onResize = () => resize();
        window.addEventListener('resize', onResize);

        // Safety net in case rAF stalls (backgrounded tab, slow device, etc.)
        const safetyTimer = window.setTimeout(finish, TOTAL_DURATION_MS + 1500);

        return () => {
            window.removeEventListener('resize', onResize);
            window.clearTimeout(safetyTimer);
            if (raf) cancelAnimationFrame(raf);
        };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    return (
        <div
            ref={stageRef}
            className='studioIntro'
            onClick={onComplete}
            role='button'
            tabIndex={0}
            aria-label='Skip intro'
        >
            <canvas ref={canvasRefs[0]} className='studioIntro-canvas' />
            <canvas ref={canvasRefs[1]} className='studioIntro-canvas' />
            <canvas ref={canvasRefs[2]} className='studioIntro-canvas' />
            <canvas ref={canvasRefs[3]} className='studioIntro-canvas' />

            <div className='studioIntro-ui'>
                <div ref={nameRef} className='studioIntro-name'>{name}</div>
                <div ref={taglineRef} className='studioIntro-tagline'>{tagline}</div>
            </div>

            <div className='studioIntro-skipHint'>Toque para pular</div>
        </div>
    );
};

export default StudioIntro;
