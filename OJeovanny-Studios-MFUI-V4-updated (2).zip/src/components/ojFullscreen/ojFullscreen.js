import browser from '../../scripts/browser';

/**
 * Requests fullscreen on the very first tap/click the user makes anywhere
 * on the page. Browsers block requestFullscreen() unless it's called
 * directly inside a real user-gesture event handler, so we can't fire this
 * automatically on page load — this is the closest equivalent: it fires on
 * the first interaction, before the user has even chosen where to go.
 *
 * Skipped when:
 *  - The Fullscreen API isn't available (most iOS Safari browsers)
 *  - The app is already running installed/standalone (already chromeless)
 *  - The app is already in fullscreen for any other reason
 *  - Running on TV/console platforms (already kiosk/fullscreen natively)
 */
export function enableFullscreenOnFirstInteraction() {
    if (browser.tv || browser.xboxOne || browser.ps4) return;

    const docEl = document.documentElement;

    const canRequestFullscreen = Boolean(
        docEl.requestFullscreen
        || docEl.webkitRequestFullscreen
        || docEl.mozRequestFullScreen
        || docEl.msRequestFullscreen
    );

    if (!canRequestFullscreen) return;

    const isStandalone = window.matchMedia?.('(display-mode: standalone)')?.matches
        || window.navigator.standalone === true;

    if (isStandalone) return;

    const requestFullscreen = () => {
        const request = docEl.requestFullscreen
            || docEl.webkitRequestFullscreen
            || docEl.mozRequestFullScreen
            || docEl.msRequestFullscreen;

        try {
            const result = request.call(docEl);
            // Some browsers return a Promise that rejects silently
            // (e.g. permissions policy); swallow it so nothing surfaces
            // to the user if it doesn't work.
            if (result?.catch) result.catch(() => undefined);
        } catch {
            // Ignore - fullscreen just won't happen this session.
        }
    };

    const onFirstInteraction = () => {
        document.removeEventListener('pointerdown', onFirstInteraction);

        const alreadyFullscreen = document.fullscreenElement
            || document.webkitFullscreenElement
            || document.mozFullScreenElement
            || document.msFullscreenElement;

        if (!alreadyFullscreen) requestFullscreen();
    };

    document.addEventListener('pointerdown', onFirstInteraction, { once: true });
}

export default enableFullscreenOnFirstInteraction;
