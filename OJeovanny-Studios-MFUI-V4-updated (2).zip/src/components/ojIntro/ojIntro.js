// Controls the OJeovanny boot intro (#ojIntro, defined in index.html):
// a real progress bar driven by the actual app boot steps in index.jsx,
// instead of the old Jellyfin splash logo + purple infinite spinner.

const FADE_OUT_DELAY_MS = 500;
const FADE_OUT_SAFETY_MS = 900;

function getIntroElements() {
    return {
        intro: document.getElementById('ojIntro'),
        fill: document.getElementById('ojIntroFill'),
        status: document.getElementById('ojIntroStatus')
    };
}

/**
 * Updates the intro's progress bar and status label.
 * @param {number} percent - 0 to 100
 * @param {string} [label] - status text shown under the bar
 */
export function setIntroProgress(percent, label) {
    const { fill, status } = getIntroElements();

    if (fill) {
        fill.style.width = `${Math.max(0, Math.min(100, percent))}%`;
    }

    if (status && label) {
        status.textContent = label;
    }
}

/**
 * Completes the intro: fills the bar to 100%, waits briefly so the
 * person can register that loading finished, then fades the intro
 * out and removes it from the DOM.
 */
export function finishIntro() {
    const { intro } = getIntroElements();
    if (!intro) return;

    setIntroProgress(100, 'Pronto');

    window.setTimeout(() => {
        intro.classList.add('oj-intro--fade-out');

        const removeIntro = () => intro.remove();
        intro.addEventListener('transitionend', removeIntro, { once: true });
        // Safety net in case the transitionend event doesn't fire
        // (e.g. the tab was backgrounded mid-fade).
        window.setTimeout(removeIntro, FADE_OUT_SAFETY_MS);
    }, FADE_OUT_DELAY_MS);
}
