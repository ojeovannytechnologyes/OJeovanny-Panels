// Simple calibration wizard for gamepads that don't report the W3C "standard"
// mapping (gamepad.mapping === ''). Common with older DirectInput joysticks,
// generic USB adapters, and some 8bitdo controllers in "D" mode.
//
// The wizard asks the person to press each control once (D-pad x4, A, B).
// Whatever button index changes state — or whichever axis moves past the
// threshold, to also support hat-switch style D-pads — gets recorded as
// that role's mapping. The result is saved per gamepad.id via appSettings
// and consumed by gamepadtokey.js on every subsequent connection of that
// same controller.

export const CALIBRATION_STEPS = [
    { key: 'up', labelKey: 'CalibrateDpadUp' },
    { key: 'down', labelKey: 'CalibrateDpadDown' },
    { key: 'left', labelKey: 'CalibrateDpadLeft' },
    { key: 'right', labelKey: 'CalibrateDpadRight' },
    { key: 'a', labelKey: 'CalibrateButtonA' },
    { key: 'b', labelKey: 'CalibrateButtonB' }
];

const AXIS_THRESHOLD = 0.5;
// Small pause after a step is captured, so the same physical press isn't
// immediately re-captured for the next step.
const DEBOUNCE_MS = 450;

class GamepadCalibration {
    _running = false;
    _frame = null;
    _debounceTimer = null;

    /**
     * @return {boolean} Whether a calibration is currently in progress.
     */
    isRunning() {
        return this._running;
    }

    /**
     * Begin calibrating the gamepad at the given navigator.getGamepads() index.
     * @param {number} gamepadIndex
     * @param {Function} onStep - called with (step, stepIndex, totalSteps) each time a new step begins.
     * @param {Function} onComplete - called with ({ buttons, axes }) when all steps finish.
     * @param {Function} onCancel - called (with an optional reason string) if calibration stops early.
     */
    start(gamepadIndex, onStep, onComplete, onCancel) {
        this.cancel('restart');

        this._gamepadIndex = gamepadIndex;
        this._stepIndex = 0;
        this._result = { buttons: {}, axes: {} };
        this._onStep = onStep;
        this._onComplete = onComplete;
        this._onCancel = onCancel;
        this._running = true;
        this._baseline = this._snapshot();

        if (!this._baseline) {
            this._running = false;
            this._onCancel?.('disconnected');
            return;
        }

        this._reportCurrentStep();
        this._frame = requestAnimationFrame(() => this._poll());
    }

    /**
     * Stop calibration early.
     * @param {string} [reason] - Why calibration is being cancelled, passed through to onCancel.
     */
    cancel(reason) {
        if (this._frame) {
            cancelAnimationFrame(this._frame);
            this._frame = null;
        }
        if (this._debounceTimer) {
            clearTimeout(this._debounceTimer);
            this._debounceTimer = null;
        }
        const wasRunning = this._running;
        this._running = false;

        if (wasRunning && reason !== 'restart') {
            this._onCancel?.(reason);
        }
    }

    _snapshot() {
        const gamepads = navigator.getGamepads(); /* eslint-disable-line compat/compat */
        const gp = gamepads[this._gamepadIndex];
        if (!gp) {
            return null;
        }
        return {
            buttons: gp.buttons.map(b => b.pressed || b.value > 0.5),
            axes: gp.axes.slice()
        };
    }

    _reportCurrentStep() {
        const step = CALIBRATION_STEPS[this._stepIndex];
        this._onStep?.(step, this._stepIndex, CALIBRATION_STEPS.length);
    }

    _poll() {
        if (!this._running) {
            return;
        }

        const gamepads = navigator.getGamepads(); /* eslint-disable-line compat/compat */
        const gp = gamepads[this._gamepadIndex];
        if (!gp) {
            this.cancel('disconnected');
            return;
        }

        const step = CALIBRATION_STEPS[this._stepIndex];
        let matched = false;

        // Prefer buttons: most direct and unambiguous signal.
        for (let i = 0; i < gp.buttons.length && !matched; i++) {
            const pressedNow = gp.buttons[i].pressed || gp.buttons[i].value > 0.5;
            const pressedBefore = this._baseline.buttons[i];
            if (pressedNow && !pressedBefore) {
                this._result.buttons[step.key] = i;
                matched = true;
            }
        }

        // Fall back to axes, to support hat-switch D-pads / sticks used as a D-pad.
        if (!matched) {
            for (let i = 0; i < gp.axes.length; i++) {
                const val = gp.axes[i];
                const baseVal = this._baseline.axes[i] || 0;
                if (Math.abs(val - baseVal) > AXIS_THRESHOLD) {
                    this._result.axes[step.key] = { axis: i, sign: val > baseVal ? 1 : -1 };
                    matched = true;
                    break;
                }
            }
        }

        if (matched) {
            this._stepIndex++;

            if (this._stepIndex >= CALIBRATION_STEPS.length) {
                this._running = false;
                this._onComplete?.(this._result);
                return;
            }

            this._reportCurrentStep();

            this._debounceTimer = setTimeout(() => {
                if (!this._running) {
                    return;
                }
                this._baseline = this._snapshot();
                if (!this._baseline) {
                    this.cancel('disconnected');
                    return;
                }
                this._frame = requestAnimationFrame(() => this._poll());
            }, DEBOUNCE_MS);
            return;
        }

        this._frame = requestAnimationFrame(() => this._poll());
    }
}

export default new GamepadCalibration();
