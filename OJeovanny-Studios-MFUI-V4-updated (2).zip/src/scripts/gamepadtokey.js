// #      The MIT License (MIT)
// #
// #      Copyright (c) 2016 Microsoft. All rights reserved.
// #
// #      Permission is hereby granted, free of charge, to any person obtaining a copy
// #      of this software and associated documentation files (the "Software"), to deal
// #      in the Software without restriction, including without limitation the rights
// #      to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// #      copies of the Software, and to permit persons to whom the Software is
// #      furnished to do so, subject to the following conditions:
// #
// #      The above copyright notice and this permission notice shall be included in
// #      all copies or substantial portions of the Software.
// #
// #      THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// #      IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// #      FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// #      AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// #      LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// #      OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// #      THE SOFTWARE.

import { appHost } from '../components/apphost';
import layoutManager from '../components/layoutManager';
import appSettings from './settings/appSettings';

const _GAMEPAD_A_BUTTON_INDEX = 0;
const _GAMEPAD_B_BUTTON_INDEX = 1;
const _GAMEPAD_DPAD_UP_BUTTON_INDEX = 12;
const _GAMEPAD_DPAD_DOWN_BUTTON_INDEX = 13;
const _GAMEPAD_DPAD_LEFT_BUTTON_INDEX = 14;
const _GAMEPAD_DPAD_RIGHT_BUTTON_INDEX = 15;
const _GAMEPAD_A_KEY = 'GamepadA';
const _GAMEPAD_B_KEY = 'GamepadB';
const _GAMEPAD_DPAD_UP_KEY = 'GamepadDPadUp';
const _GAMEPAD_DPAD_DOWN_KEY = 'GamepadDPadDown';
const _GAMEPAD_DPAD_LEFT_KEY = 'GamepadDPadLeft';
const _GAMEPAD_DPAD_RIGHT_KEY = 'GamepadDPadRight';
const _GAMEPAD_LEFT_THUMBSTICK_UP_KEY = 'GamepadLeftThumbStickUp';
const _GAMEPAD_LEFT_THUMBSTICK_DOWN_KEY = 'GamepadLeftThumbStickDown';
const _GAMEPAD_LEFT_THUMBSTICK_LEFT_KEY = 'GamepadLeftThumbStickLeft';
const _GAMEPAD_LEFT_THUMBSTICK_RIGHT_KEY = 'GamepadLeftThumbStickRight';
const _GAMEPAD_A_KEYCODE = 13;
const _GAMEPAD_B_KEYCODE = 27;
const _GAMEPAD_DPAD_UP_KEYCODE = 38;
const _GAMEPAD_DPAD_DOWN_KEYCODE = 40;
const _GAMEPAD_DPAD_LEFT_KEYCODE = 37;
const _GAMEPAD_DPAD_RIGHT_KEYCODE = 39;
const _GAMEPAD_LEFT_THUMBSTICK_UP_KEYCODE = 38;
const _GAMEPAD_LEFT_THUMBSTICK_DOWN_KEYCODE = 40;
const _GAMEPAD_LEFT_THUMBSTICK_LEFT_KEYCODE = 37;
const _GAMEPAD_LEFT_THUMBSTICK_RIGHT_KEYCODE = 39;
const _THUMB_STICK_THRESHOLD = 0.75;

let _leftThumbstickUpPressed = false;
let _leftThumbstickDownPressed = false;
let _leftThumbstickLeftPressed = false;
let _leftThumbstickRightPressed = false;
let _dPadUpPressed = false;
let _dPadDownPressed = false;
let _dPadLeftPressed = false;
let _dPadRightPressed = false;
let _gamepadADownEvent = null;
let _gamepadAPressed = false;
let _gamepadBPressed = false;

const _ButtonPressedState = {};
_ButtonPressedState.getgamepadA = function () {
    return _gamepadAPressed;
};

_ButtonPressedState.setgamepadA = function (newPressedState) {
    const newPressedEvent = raiseKeyEvent(_gamepadAPressed, newPressedState, _GAMEPAD_A_KEY, _GAMEPAD_A_KEYCODE, false, true, _gamepadADownEvent);
    _gamepadAPressed = newPressedState;

    if (!newPressedState) {
        // reset on keyup
        _gamepadADownEvent = null;
    } else if (newPressedEvent != null) {
        _gamepadADownEvent = newPressedEvent;
    }
};

_ButtonPressedState.getgamepadB = function () {
    return _gamepadBPressed;
};

_ButtonPressedState.setgamepadB = function (newPressedState) {
    raiseKeyEvent(_gamepadBPressed, newPressedState, _GAMEPAD_B_KEY, _GAMEPAD_B_KEYCODE);
    _gamepadBPressed = newPressedState;
};

_ButtonPressedState.getleftThumbstickUp = function () {
    return _leftThumbstickUpPressed;
};

_ButtonPressedState.setleftThumbstickUp = function (newPressedState) {
    raiseKeyEvent(_leftThumbstickUpPressed, newPressedState, _GAMEPAD_LEFT_THUMBSTICK_UP_KEY, _GAMEPAD_LEFT_THUMBSTICK_UP_KEYCODE, true);
    _leftThumbstickUpPressed = newPressedState;
};

_ButtonPressedState.getleftThumbstickDown = function () {
    return _leftThumbstickDownPressed;
};

_ButtonPressedState.setleftThumbstickDown = function (newPressedState) {
    raiseKeyEvent(_leftThumbstickDownPressed, newPressedState, _GAMEPAD_LEFT_THUMBSTICK_DOWN_KEY, _GAMEPAD_LEFT_THUMBSTICK_DOWN_KEYCODE, true);
    _leftThumbstickDownPressed = newPressedState;
};

_ButtonPressedState.getleftThumbstickLeft = function () {
    return _leftThumbstickLeftPressed;
};

_ButtonPressedState.setleftThumbstickLeft = function (newPressedState) {
    raiseKeyEvent(_leftThumbstickLeftPressed, newPressedState, _GAMEPAD_LEFT_THUMBSTICK_LEFT_KEY, _GAMEPAD_LEFT_THUMBSTICK_LEFT_KEYCODE, true);
    _leftThumbstickLeftPressed = newPressedState;
};

_ButtonPressedState.getleftThumbstickRight = function () {
    return _leftThumbstickRightPressed;
};

_ButtonPressedState.setleftThumbstickRight = function (newPressedState) {
    raiseKeyEvent(_leftThumbstickRightPressed, newPressedState, _GAMEPAD_LEFT_THUMBSTICK_RIGHT_KEY, _GAMEPAD_LEFT_THUMBSTICK_RIGHT_KEYCODE, true);
    _leftThumbstickRightPressed = newPressedState;
};

_ButtonPressedState.getdPadUp = function () {
    return _dPadUpPressed;
};

_ButtonPressedState.setdPadUp = function (newPressedState) {
    raiseKeyEvent(_dPadUpPressed, newPressedState, _GAMEPAD_DPAD_UP_KEY, _GAMEPAD_DPAD_UP_KEYCODE, true);
    _dPadUpPressed = newPressedState;
};

_ButtonPressedState.getdPadDown = function () {
    return _dPadDownPressed;
};

_ButtonPressedState.setdPadDown = function (newPressedState) {
    raiseKeyEvent(_dPadDownPressed, newPressedState, _GAMEPAD_DPAD_DOWN_KEY, _GAMEPAD_DPAD_DOWN_KEYCODE, true);
    _dPadDownPressed = newPressedState;
};

_ButtonPressedState.getdPadLeft = function () {
    return _dPadLeftPressed;
};

_ButtonPressedState.setdPadLeft = function (newPressedState) {
    raiseKeyEvent(_dPadLeftPressed, newPressedState, _GAMEPAD_DPAD_LEFT_KEY, _GAMEPAD_DPAD_LEFT_KEYCODE, true);
    _dPadLeftPressed = newPressedState;
};

_ButtonPressedState.getdPadRight = function () {
    return _dPadRightPressed;
};

_ButtonPressedState.setdPadRight = function (newPressedState) {
    raiseKeyEvent(_dPadRightPressed, newPressedState, _GAMEPAD_DPAD_RIGHT_KEY, _GAMEPAD_DPAD_RIGHT_KEYCODE, true);
    _dPadRightPressed = newPressedState;
};

// Default button index for each logical "role", used when no custom
// calibration is saved for this gamepad (this is the original XInput-style
// behavior, unchanged).
const _ROLE_DEFAULT_BUTTON_INDEX = {
    up: _GAMEPAD_DPAD_UP_BUTTON_INDEX,
    down: _GAMEPAD_DPAD_DOWN_BUTTON_INDEX,
    left: _GAMEPAD_DPAD_LEFT_BUTTON_INDEX,
    right: _GAMEPAD_DPAD_RIGHT_BUTTON_INDEX,
    a: _GAMEPAD_A_BUTTON_INDEX,
    b: _GAMEPAD_B_BUTTON_INDEX
};

// Maps each role to the setter that raises the corresponding key event.
const _ROLE_SETTERS = {
    up: _ButtonPressedState.setdPadUp,
    down: _ButtonPressedState.setdPadDown,
    left: _ButtonPressedState.setdPadLeft,
    right: _ButtonPressedState.setdPadRight,
    a: _ButtonPressedState.setgamepadA,
    b: _ButtonPressedState.setgamepadB
};

const _GAMEPAD_ROLES = ['up', 'down', 'left', 'right', 'a', 'b'];

// Non-standard (DirectInput / blank Gamepad.mapping) pads that don't have a
// saved calibration only get warned about once, not every animation frame.
const _warnedUncalibratedGamepadIds = new Set();

function warnIfUncalibrated(gamepad, mapping) {
    if (mapping || gamepad.mapping === 'standard') {
        return;
    }

    if (_warnedUncalibratedGamepadIds.has(gamepad.id)) {
        return;
    }

    _warnedUncalibratedGamepadIds.add(gamepad.id);
    console.warn(
        `[gamepadtokey] Gamepad "${gamepad.id}" does not report the standard mapping and has no saved calibration. `
        + 'D-pad/A/B input may be wrong. Calibrate it from Settings > Controls.'
    );
}

// Whether a given logical role (up/down/left/right/a/b) is currently pressed
// on this gamepad, using its saved custom mapping if one exists, otherwise
// falling back to the original default button index behavior.
function isRolePressed(gamepad, mapping, role) {
    if (mapping) {
        const buttonIndex = mapping.buttons?.[role];
        if (buttonIndex !== undefined) {
            const button = gamepad.buttons[buttonIndex];
            return !!button && (button.pressed || button.value > 0.5);
        }

        const axisMapping = mapping.axes?.[role];
        if (axisMapping !== undefined) {
            const value = gamepad.axes[axisMapping.axis] || 0;
            return axisMapping.sign > 0 ? value > _THUMB_STICK_THRESHOLD : value < -_THUMB_STICK_THRESHOLD;
        }
    }

    const defaultIndex = _ROLE_DEFAULT_BUTTON_INDEX[role];
    const button = gamepad.buttons[defaultIndex];
    return !!button && button.pressed;
}

const times = {};

function throttle(key) {
    const time = times[key] || 0;
    const now = new Date().getTime();

    return (now - time) >= 200;
}

function resetThrottle(key) {
    times[key] = new Date().getTime();
}

const isElectron = navigator.userAgent.toLowerCase().indexOf('electron') !== -1;
function allowInput() {
    // This would be nice but always seems to return true with electron
    if (!isElectron && document.hidden) {
        return false;
    }

    return appHost.getWindowState() !== 'Minimized';
}

function raiseEvent(name, key, keyCode) {
    if (!allowInput()) {
        return;
    }

    const event = new Event(name, { bubbles: true, cancelable: true });
    event.key = key;
    event.keyCode = keyCode;
    (document.activeElement || document.body).dispatchEvent(event);

    return event;
}

function clickElement(elem) {
    if (!allowInput()) {
        return;
    }

    elem.click();
}

function raiseKeyEvent(oldPressedState, newPressedState, key, keyCode, enableRepeatKeyDown, clickonKeyUp, oldPressedEvent) {
    let newPressedEvent = null;

    // No-op if oldPressedState === newPressedState
    if (newPressedState === true) {
        // button down
        let fire = false;

        // always fire if this is the initial down press
        if (oldPressedState === false) {
            fire = true;
            resetThrottle(key);
        } else if (enableRepeatKeyDown) {
            fire = throttle(key);
        }

        if (fire && keyCode) {
            newPressedEvent = raiseEvent('keydown', key, keyCode);
        }
    } else if (newPressedState === false && oldPressedState === true) {
        resetThrottle(key);

        // button up
        if (keyCode) {
            newPressedEvent = raiseEvent('keyup', key, keyCode);
        }
        if (clickonKeyUp && !oldPressedEvent?.defaultPrevented && !newPressedEvent?.defaultPrevented) {
            clickElement(document.activeElement || window);
        }
    }

    return newPressedEvent;
}

let inputLoopTimer;
function runInputLoop() {
    // Get the latest gamepad state.
    const gamepads = navigator.getGamepads(); /* eslint-disable-line compat/compat */
    for (let i = 0, len = gamepads.length; i < len; i++) {
        const gamepad = gamepads[i];
        if (!gamepad) {
            continue;
        }
        // Iterate through the axes
        const axes = gamepad.axes;
        const leftStickX = axes[0];
        const leftStickY = axes[1];
        if (leftStickX > _THUMB_STICK_THRESHOLD) { // Right
            _ButtonPressedState.setleftThumbstickRight(true);
        } else if (leftStickX < -_THUMB_STICK_THRESHOLD) { // Left
            _ButtonPressedState.setleftThumbstickLeft(true);
        } else if (leftStickY < -_THUMB_STICK_THRESHOLD) { // Up
            _ButtonPressedState.setleftThumbstickUp(true);
        } else if (leftStickY > _THUMB_STICK_THRESHOLD) { // Down
            _ButtonPressedState.setleftThumbstickDown(true);
        } else {
            _ButtonPressedState.setleftThumbstickLeft(false);
            _ButtonPressedState.setleftThumbstickRight(false);
            _ButtonPressedState.setleftThumbstickUp(false);
            _ButtonPressedState.setleftThumbstickDown(false);
        }
        // Resolve DPad/A/B state per logical role, using this gamepad's saved
        // custom calibration if one exists (needed for DirectInput / non-
        // "standard" pads), otherwise falling back to the default indices.
        const mapping = appSettings.getGamepadMapping(gamepad.id);
        warnIfUncalibrated(gamepad, mapping);

        for (const role of _GAMEPAD_ROLES) {
            _ROLE_SETTERS[role](isRolePressed(gamepad, mapping, role));
        }
    }
    // Schedule the next one
    inputLoopTimer = requestAnimationFrame(runInputLoop);
}

function startInputLoop() {
    if (!inputLoopTimer) {
        runInputLoop();
    }
}

function stopInputLoop() {
    cancelAnimationFrame(inputLoopTimer);
    inputLoopTimer = undefined;
}

function isGamepadConnected() {
    const gamepads = navigator.getGamepads(); /* eslint-disable-line compat/compat */
    for (let i = 0, len = gamepads.length; i < len; i++) {
        const gamepad = gamepads[i];
        if (gamepad?.connected) {
            return true;
        }
    }
    return false;
}

function onFocusOrGamepadAttach() {
    if (isGamepadConnected() && document.hasFocus()) {
        console.log('Gamepad connected! Starting input loop');
        startInputLoop();

        // Same idea as Xbox Cloud Gaming: the moment a real controller is
        // detected, switch the whole UI into TV/controller layout right
        // away, instead of waiting for the person to happen to press a
        // D-pad direction first (they might press A/B first and nothing
        // would ever trigger it).
        if (!layoutManager.tv) {
            console.debug('Physical gamepad detected — enabling TV layout automatically');
            layoutManager.setLayout('tv', false);
        }
    }
}

function onFocusOrGamepadDetach() {
    if (!isGamepadConnected() || !document.hasFocus()) {
        console.log('Gamepad disconnected! No other gamepads are connected, stopping input loop');
        stopInputLoop();
    } else {
        console.log('Gamepad disconnected! There are gamepads still connected.');
    }
}

// Event listeners for any change in gamepads' state.
window.addEventListener('gamepaddisconnected', onFocusOrGamepadDetach);
window.addEventListener('gamepadconnected', onFocusOrGamepadAttach);
window.addEventListener('blur', onFocusOrGamepadDetach);
window.addEventListener('focus', onFocusOrGamepadAttach);

onFocusOrGamepadAttach();

// The gamepadInputEmulation is a string property that exists in JavaScript UWAs and in WebViews in UWAs.
// It won't exist in Win8.1 style apps or browsers.
if (window.navigator && typeof window.navigator.gamepadInputEmulation === 'string') {
    // We want the gamepad to provide gamepad VK keyboard events rather than moving a
    // mouse like cursor. Set to "keyboard", the gamepad will provide such keyboard events
    // and provide input to the DOM navigator.getGamepads API.
    window.navigator.gamepadInputEmulation = 'gamepad';
}
