import React, { type FC } from 'react';
import { useQuery } from '@tanstack/react-query';
import { getItemsApi } from '@jellyfin/sdk/lib/utils/api/items-api';
import { getUserLibraryApi } from '@jellyfin/sdk/lib/utils/api/user-library-api';
import { ItemFields } from '@jellyfin/sdk/lib/generated-client/models/item-fields';
import { ImageType } from '@jellyfin/sdk/lib/generated-client/models/image-type';

import Page from 'components/Page';
import { appRouter } from 'components/router/appRouter';
import { useApi } from 'hooks/useApi';
import { useUserViews } from 'hooks/useUserViews';

import type { ItemDto } from 'types/base/models/item-dto';
import HomeNav, { buildNavLinks } from './HomeNav';
import HomeHero from './HomeHero';
import ContinueWatchingRow from './ContinueWatchingRow';
import HomeRow, { type HomeCardItem } from './HomeRow';
import BottomNav from './BottomNav';
import './home2.scss';

const RESUME_ITEMS_LIMIT = 9;

const fetchResumeItems = async (api: ReturnType<typeof useApi>['api'], userId?: string) => {
    if (!api || !userId) return [];

    const response = await getItemsApi(api).getResumeItems({
        userId,
        limit: RESUME_ITEMS_LIMIT,
        fields: [
            ItemFields.PrimaryImageAspectRatio,
            ItemFields.MediaSourceCount
        ],
        imageTypeLimit: 1,
        enableImageTypes: [
            ImageType.Primary,
            ImageType.Thumb,
            ImageType.Backdrop
        ],
        enableTotalRecordCount: false
    });

    return response.data.Items ?? [];
};

// Passo 1 (fallback do hero): quando não há nada em "continuar assistindo",
// usamos o item mais recente adicionado na primeira biblioteca do usuário
// (mesma ideia de "lançamentos recentes" descrita no Passo 2 do prompt).
const fetchLatestMedia = async (
    api: ReturnType<typeof useApi>['api'],
    userId: string | undefined,
    firstLibraryId: string | undefined
): Promise<ItemDto[]> => {
    if (!api || !userId) return [];

    const response = await getUserLibraryApi(api).getLatestMedia({
        userId,
        parentId: firstLibraryId,
        limit: 1,
        fields: [
            ItemFields.PrimaryImageAspectRatio,
            ItemFields.MediaSourceCount,
            ItemFields.Genres,
            ItemFields.Overview
        ],
        imageTypeLimit: 1,
        enableImageTypes: [
            ImageType.Primary,
            ImageType.Thumb,
            ImageType.Backdrop
        ]
    });

    return response.data ?? [];
};

const LIBRARY_SHORTCUT_ICONS: Record<string, string> = {
    tvshows: 'ti-device-tv',
    movies: 'ti-movie',
    music: 'ti-music',
    playlists: 'ti-playlist',
    books: 'ti-book',
    homevideos: 'ti-video'
};

const buildLibraryCards = (userViews: ItemDto[] | undefined): HomeCardItem[] => {
    if (!userViews?.length) return [];

    return userViews.map(view => {
        const collectionType = view.CollectionType ?? undefined;

        return {
            key: view.Id ?? view.Name ?? Math.random().toString(36),
            item: view,
            title: view.Name ?? '',
            icon: (collectionType && LIBRARY_SHORTCUT_ICONS[collectionType]) ?? 'ti-folder',
            href: appRouter.getRouteUrl(view, { context: collectionType }).substring(1)
        };
    });
};

const Home2: FC = () => {
    const { api, user } = useApi();
    const { data: userViews } = useUserViews(user?.Id);

    const { data: resumeItems = [] } = useQuery({
        queryKey: [ 'Home2', 'ResumeItems', user?.Id ],
        queryFn: () => fetchResumeItems(api, user?.Id),
        enabled: !!api && !!user?.Id,
        staleTime: 1000
    });

    const firstLibraryId = userViews?.[0]?.Id ?? undefined;

    // Só busca "lançamentos recentes" quando já sabemos que não há nada em
    // "continuar assistindo" — evita uma chamada extra desnecessária na
    // maioria dos casos.
    const { data: latestMediaItems = [] } = useQuery({
        queryKey: [ 'Home2', 'LatestMedia', user?.Id, firstLibraryId ],
        queryFn: () => fetchLatestMedia(api, user?.Id, firstLibraryId),
        enabled: !!api && !!user?.Id && resumeItems.length === 0,
        staleTime: 1000
    });

    const navLinks = buildNavLinks(userViews);
    const libraryCards = buildLibraryCards(userViews);

    // Hero: primeiro item de "continuar assistindo"; se não houver nenhum,
    // cai no item mais recente adicionado na primeira biblioteca do usuário.
    const heroItem = resumeItems[0] ?? latestMediaItems[0];

    const continueWatchingItems = resumeItems.slice(0, RESUME_ITEMS_LIMIT);

    return (
        <Page
            id='home2Page'
            className='mainAnimatedPage homePage libraryPage allLibraryPage backdropPage oj-root'
            isBackButtonEnabled={false}
            backDropType='movie,series,book'
        >
            <HomeNav navLinks={navLinks} />

            <HomeHero item={heroItem} />

            <ContinueWatchingRow
                title='Continuar assistindo'
                items={continueWatchingItems}
                getHref={(item) => appRouter.getRouteUrl(item, { context: item.CollectionType ?? undefined }).substring(1)}
            />

            <HomeRow
                title='Minha biblioteca'
                cards={libraryCards}
            />

            <BottomNav navLinks={navLinks} />
        </Page>
    );
};

export default Home2;
