#!/bin/bash
# ── Minecraft Panel - Instalação ─────────────────────────────────────────────
set -e

echo ""
echo "⛏  Minecraft Panel - Instalação"
echo "─────────────────────────────────"

# Verifica Node.js
if ! command -v node &> /dev/null; then
  echo "❌ Node.js não encontrado. Instale com:"
  echo "   sudo apt install nodejs npm    (Ubuntu/Debian)"
  echo "   ou baixe em https://nodejs.org"
  exit 1
fi

NODE_VER=$(node -v)
echo "✓ Node.js $NODE_VER encontrado"

# Instala dependências
echo ""
echo "📦 Instalando dependências..."
npm install --no-audit --no-fund

# Cria .env se não existir
if [ ! -f .env ]; then
  echo ""
  echo "📝 Criando .env a partir do .env.example..."
  cp .env.example .env
  echo ""
  echo "⚠️  IMPORTANTE: Edite o arquivo .env antes de iniciar!"
  echo "    nano .env"
  echo ""
  echo "   Configure ao menos:"
  echo "   - MC_SERVER_DIR  → pasta do seu servidor Minecraft"
  echo "   - PANEL_PASSWORD → senha de acesso ao painel"
  echo "   - MC_START_CMD   → comando para iniciar o servidor"
  echo ""
  echo "   Depois execute: node server.js"
else
  echo "✓ .env já existe"
  echo ""
  echo "🟢 Iniciando painel na porta 2049..."
  node server.js
fi
