# ⛏ Minecraft Panel

Painel web completo para gerenciar seu servidor Minecraft na Oracle Cloud (ou qualquer VPS Linux).

## Funcionalidades

- **Dashboard** — status do servidor, players online, CPU/RAM/disco, atividade do dia
- **Controle do servidor** — start / stop / restart / kill via screen
- **Console** — envie comandos direto ao servidor (via screen, sem RCON)
- **RCON** — console com resposta em tempo real (opcional)
- **Players** — quem entrou/saiu hoje, comandos, mensagens, mortes
- **Logs** — visualize logs arquivados por data
- **Whitelist / Ops / Bans** — gerencie diretamente pelo painel
- **Backup** — crie e baixe backups .zip do mundo
- **server.properties** — edite configurações sem precisar de terminal
- **Autenticação** — senha de admin com sessão por cookie seguro

---

## Instalação rápida

```bash
# 1. Extraia o zip
unzip minecraft-panel.zip
cd minecraft-panel

# 2. Instale dependências e configure
chmod +x install.sh
./install.sh

# 3. Edite o .env com suas configurações
nano .env

# 4. Inicie o painel
node server.js
```

---

## Configuração (.env)

| Variável | Padrão | Descrição |
|---|---|---|
| `PANEL_PORT` | `2049` | Porta do painel |
| `MC_SERVER_DIR` | `/home/ubuntu/minecraft` | Pasta raiz do servidor |
| `MC_LOG_FILE` | `…/logs/latest.log` | Arquivo de log |
| `MC_START_CMD` | `java -Xmx2G … -jar server.jar nogui` | Comando de start |
| `MC_SCREEN` | `minecraft` | Nome da sessão screen |
| `PANEL_PASSWORD` | *(vazio)* | Senha do painel — **defina isso!** |
| `PANEL_SECRET` | *(gerado)* | Segredo das sessões |
| `RCON_ENABLED` | `false` | Ativar RCON |
| `RCON_PASS` | *(vazio)* | Senha do RCON |

---

## Abrindo a porta 2049 na Oracle Cloud

No console da Oracle Cloud:
1. VCN → Security Lists → Inbound Rules
2. Add: TCP, porta 2049, source 0.0.0.0/0
3. No servidor: `sudo iptables -I INPUT -p tcp --dport 2049 -j ACCEPT`

Acesse: `http://SEU_IP_PUBLICO:2049`

---

## Mantendo o painel rodando (sem screen cair)

```bash
# Opção 1: screen separado para o painel
screen -dmS mcpanel node /caminho/minecraft-panel/server.js

# Opção 2: systemd (recomendado para produção)
# Crie /etc/systemd/system/mcpanel.service e habilite
```

---

## Sobre o controle via screen

O painel gerencia a sessão screen do Minecraft automaticamente:
- **Sempre 1 sessão** com o nome definido em `MC_SCREEN`
- **Nunca duplica** sessões orphans
- **Start/Stop/Restart** funcionam mesmo sem RCON
- Se o servidor Java cair, a sessão screen fica viva com um shell (`exec bash`), então você pode reconectar com `screen -r minecraft` e ver o que aconteceu

---

## Estrutura dos arquivos

```
minecraft-panel/
├── server.js          ← Backend principal (Express)
├── package.json
├── .env               ← Suas configurações (não commitar!)
├── .env.example       ← Template
├── install.sh         ← Script de instalação
├── public/
│   └── index.html     ← Frontend completo
└── lib/
    ├── auth.js        ← Autenticação (cookie HMAC)
    ├── backup.js      ← Backup do mundo (.zip)
    ├── configEditor.js ← Whitelist/ops/bans/properties
    ├── rcon.js        ← Protocolo RCON nativo (sem binários)
    └── screenManager.js ← Gerenciador de sessão screen
```
