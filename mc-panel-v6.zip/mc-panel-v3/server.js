try { require('dotenv').config(); } catch { /* dotenv é opcional; segue com process.env / defaults */ }

const express = require('express');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { execSync, exec } = require('child_process');
const readline = require('readline');

const { rconCommand } = require('./lib/rcon');
const screenMgr = require('./lib/screenManager');
const auth = require('./lib/auth');
const backup = require('./lib/backup');
const configEditor = require('./lib/configEditor');

const app = express();
const PORT = parseInt(process.env.PANEL_PORT || '2049');

app.use(express.json());
app.use(express.static('public'));

// ── CONFIG ──────────────────────────────────────────────────────────────
// Edite conforme seu servidor Minecraft (de preferência via arquivo .env)
const CONFIG = {
  serverDir: process.env.MC_SERVER_DIR || '/home/ubuntu/minecraft',
  logFile:   process.env.MC_LOG_FILE   || '/home/ubuntu/minecraft/logs/latest.log',
  logsDir:   process.env.MC_LOGS_DIR   || '/home/ubuntu/minecraft/logs',
  backupsDir: process.env.MC_BACKUPS_DIR || path.join(__dirname, 'backups'),
  startCmd:  process.env.MC_START_CMD  || 'java -Xms4G -Xmx8G -XX:+UseG1GC -XX:+ParallelRefProcEnabled -XX:MaxGCPauseMillis=200 -jar paper.jar nogui',
  gracefulStopCmd: process.env.MC_STOP_GAME_CMD || 'stop',
  screenName: process.env.MC_SCREEN    || 'minecraft',
  rconEnabled: process.env.RCON_ENABLED === 'true',
  rconHost:  process.env.RCON_HOST     || '127.0.0.1',
  rconPort:  parseInt(process.env.RCON_PORT || '25575'),
  rconPass:  process.env.RCON_PASS     || '',
  adminPassword: process.env.PANEL_PASSWORD || '',
  sessionSecret: process.env.PANEL_SECRET || crypto.randomBytes(32).toString('hex'),
};

if (!CONFIG.adminPassword) {
  console.warn('\n⚠️  AVISO: PANEL_PASSWORD não definido no .env — o painel está SEM SENHA e qualquer pessoa na rede pode controlar seu servidor!\n');
}

// Middleware de autenticação — protege todas as rotas /api/* exceto login/logout
app.use(auth.authMiddleware({ adminPassword: CONFIG.adminPassword, secret: CONFIG.sessionSecret }));

// ── HELPERS ──────────────────────────────────────────────────────────────
function readTail(filePath, lines = 500) {
  try {
    if (!fs.existsSync(filePath)) return [];
    const data = fs.readFileSync(filePath, 'utf8');
    const all = data.split('\n').filter(Boolean);
    return all.slice(-lines);
  } catch { return []; }
}

function readGzLog(filePath) {
  try {
    const out = execSync(`zcat "${filePath}" 2>/dev/null`).toString();
    return out.split('\n').filter(Boolean);
  } catch { return []; }
}

// Parse uma linha de log do Minecraft
// Formatos suportados:
//   [HH:MM:SS] [Server thread/INFO]: mensagem
//   [HH:MM:SS] [Server thread/INFO] [net.minecraft...]: mensagem
const LOG_RE = /^\[(\d{2}:\d{2}:\d{2})\] \[([^\]]+)\](?:\s\[[^\]]+\])?: (.+)$/;
const DATE_PREFIX_RE = /^\[(\d{4}-\d{2}-\d{2}) (\d{2}:\d{2}:\d{2})\] \[([^\]]+)\](?:\s\[[^\]]+\])?: (.+)$/;

function parseLine(line, dateHint) {
  let m = DATE_PREFIX_RE.exec(line);
  if (m) return { date: m[1], time: m[2], level: m[3], msg: m[4].trim() };
  m = LOG_RE.exec(line);
  if (m) return { date: dateHint || null, time: m[1], level: m[2], msg: m[3].trim() };
  return null;
}

function parseLogLines(lines, dateHint) {
  return lines.map(l => parseLine(l, dateHint)).filter(Boolean);
}

// Extrai data do nome do arquivo de log arquivado  ex: 2024-05-10-1.log.gz
function dateFromLogName(filename) {
  const m = /(\d{4}-\d{2}-\d{2})/.exec(filename);
  return m ? m[1] : null;
}

// ── EVENTS ───────────────────────────────────────────────────────────────
const JOIN_RE    = /^(\w+) joined the game$/;
const LEAVE_RE   = /^(\w+) left the game$/;
const CHAT_RE    = /^<(\w+)> (.+)$/;
const CMD_RE     = /^(\w+) issued server command: (.+)$/;
const DEATH_RE   = /^(\w+) (was|fell|drowned|burned|blew|hit|walked|died|starved|suffocated|withered|fireballed|shot|slain|squished|pummeled|tried|discovered).+$/;
const OP_RE      = /^(?:Opped|De-opped) (\w+)$/;
const KICK_RE    = /^Kicked (\w+): (.+)$/;
const BAN_RE     = /^Banning (\w+)$/;
const SAVE_RE    = /Saving the game/;
const WARN_RE    = /\[WARN\]|\[WARNING\]/i;

function classifyEvent(entry) {
  const { msg, time, date, level } = entry;
  if (JOIN_RE.test(msg))  return { type:'join',    player: JOIN_RE.exec(msg)[1],  time, date };
  if (LEAVE_RE.test(msg)) return { type:'leave',   player: LEAVE_RE.exec(msg)[1], time, date };
  if (CHAT_RE.test(msg))  { const m=CHAT_RE.exec(msg);  return { type:'chat',  player:m[1], message:m[2], time, date }; }
  if (CMD_RE.test(msg))   { const m=CMD_RE.exec(msg);   return { type:'command', player:m[1], command:m[2], time, date }; }
  if (DEATH_RE.test(msg)) return { type:'death',   player: DEATH_RE.exec(msg)[1], message: msg, time, date };
  if (SAVE_RE.test(msg))  return { type:'save',    time, date };
  if (WARN_RE.test(level||'')) return { type:'warn', message: msg, time, date };
  return { type:'info', message: msg, time, date };
}

// ── SERVER STATUS ─────────────────────────────────────────────────────────
function getServerStatus() {
  try {
    const out = execSync("ps aux | grep -E '[j]ava.*server\\.jar|[s]pigot|[p]aper|[b]ungeecord' | head -5").toString().trim();
    if (!out) return 'offline';
    return 'online';
  } catch { return 'unknown'; }
}

function getSystemInfo() {
  const info = {};
  try { info.uptime = execSync('uptime -p').toString().trim(); } catch { info.uptime = '-'; }
  try {
    const mem = execSync("free -m | awk 'NR==2{print $2,$3,$4}'").toString().trim().split(' ');
    info.memTotal = parseInt(mem[0]); info.memUsed = parseInt(mem[1]); info.memFree = parseInt(mem[2]);
  } catch { info.memTotal=0; info.memUsed=0; info.memFree=0; }
  try {
    const cpu = execSync("top -bn1 | grep 'Cpu(s)' | awk '{print $2+$4}'").toString().trim();
    info.cpu = parseFloat(cpu) || 0;
  } catch { info.cpu = 0; }
  try {
    const df = execSync(`df -h "${CONFIG.serverDir}" | tail -1 | awk '{print $2,$3,$5}'`).toString().trim().split(' ');
    info.diskTotal = df[0]; info.diskUsed = df[1]; info.diskPct = df[2];
  } catch { info.diskTotal='-'; info.diskUsed='-'; info.diskPct='-'; }
  return info;
}

// ── PARSE HOJE ────────────────────────────────────────────────────────────
function getTodayEvents() {
  const today = new Date().toISOString().slice(0,10);
  const lines = readTail(CONFIG.logFile, 3000);
  const entries = parseLogLines(lines, today);
  return entries.map(classifyEvent);
}

// ── PARSE LOG ARQUIVADO ───────────────────────────────────────────────────
function getArchivedEvents(filename) {
  const date = dateFromLogName(filename);
  const fullPath = path.join(CONFIG.logsDir, filename);
  let lines;
  if (filename.endsWith('.gz')) lines = readGzLog(fullPath);
  else lines = fs.existsSync(fullPath) ? fs.readFileSync(fullPath,'utf8').split('\n').filter(Boolean) : [];
  return parseLogLines(lines, date).map(classifyEvent);
}

// ── STATS DO DIA ──────────────────────────────────────────────────────────
function buildStats(events) {
  const players = {};
  let lastJoin = null, lastLeave = null;

  for (const ev of events) {
    const p = ev.player;
    if (!p) continue;
    if (!players[p]) players[p] = { name:p, joins:0, leaves:0, commands:[], messages:[], deaths:[] };

    if (ev.type==='join')    { players[p].joins++;   players[p].lastJoin=ev.time;  lastJoin={player:p, time:ev.time, date:ev.date}; }
    if (ev.type==='leave')   { players[p].leaves++;  players[p].lastLeave=ev.time; lastLeave={player:p, time:ev.time, date:ev.date}; }
    if (ev.type==='command') { players[p].commands.push({cmd:ev.command, time:ev.time}); }
    if (ev.type==='chat')    { players[p].messages.push({msg:ev.message, time:ev.time}); }
    if (ev.type==='death')   { players[p].deaths.push({msg:ev.message, time:ev.time}); }
  }

  return { players: Object.values(players), lastJoin, lastLeave };
}

// ── ROUTES ────────────────────────────────────────────────────────────────

// Status geral
app.get('/api/status', (req, res) => {
  const status = getServerStatus();
  const sys    = getSystemInfo();
  const events = getTodayEvents();
  const stats  = buildStats(events);
  const online = events.filter(e=>e.type==='join').map(e=>e.player)
    .filter(p => !events.find(e=>e.type==='leave' && e.player===p && e.time > (events.find(f=>f.type==='join'&&f.player===p)||{}).time));

  res.json({ status, sys, stats, onlineNow: [...new Set(online)], time: new Date().toISOString() });
});

// Eventos de hoje
app.get('/api/events/today', (req, res) => {
  const events = getTodayEvents();
  res.json({ events, count: events.length });
});

// Lista de logs arquivados
app.get('/api/logs/list', (req, res) => {
  try {
    if (!fs.existsSync(CONFIG.logsDir)) return res.json({ files: [] });
    const files = fs.readdirSync(CONFIG.logsDir)
      .filter(f => f.match(/\d{4}-\d{2}-\d{2}/) && (f.endsWith('.log') || f.endsWith('.log.gz')))
      .sort().reverse().slice(0, 30);
    res.json({ files });
  } catch(e) { res.json({ files:[], error: e.message }); }
});

// Eventos de um log arquivado
app.get('/api/logs/:filename', (req, res) => {
  const { filename } = req.params;
  if (filename.includes('..') || filename.includes('/')) return res.status(400).json({error:'invalid'});
  const events = getArchivedEvents(filename);
  const stats  = buildStats(events);
  res.json({ events, stats, count: events.length });
});

// Log bruto (últimas N linhas)
app.get('/api/logs/raw/latest', (req, res) => {
  const n = parseInt(req.query.n || '200');
  const lines = readTail(CONFIG.logFile, Math.min(n, 1000));
  res.json({ lines });
});

// Players online (via log)
app.get('/api/players', (req, res) => {
  const events = getTodayEvents();
  const stats  = buildStats(events);
  res.json({ players: stats.players, lastJoin: stats.lastJoin, lastLeave: stats.lastLeave });
});

// Histórico de um player específico (todos os logs)
app.get('/api/player/:name/history', (req, res) => {
  const name = req.params.name;
  const allEvents = getTodayEvents();
  try {
    if (fs.existsSync(CONFIG.logsDir)) {
      const files = fs.readdirSync(CONFIG.logsDir)
        .filter(f => f.match(/\d{4}-\d{2}-\d{2}/) && (f.endsWith('.log') || f.endsWith('.log.gz')))
        .sort().reverse().slice(0,14);
      for (const f of files) allEvents.push(...getArchivedEvents(f));
    }
  } catch{}
  const playerEvents = allEvents.filter(e => e.player === name);
  res.json({ player: name, events: playerEvents, count: playerEvents.length });
});

// Busca no log
app.get('/api/search', (req, res) => {
  const q = (req.query.q || '').toLowerCase();
  if (!q) return res.json({ results: [] });
  const events = getTodayEvents();
  const results = events.filter(e =>
    (e.player && e.player.toLowerCase().includes(q)) ||
    (e.message && e.message.toLowerCase().includes(q)) ||
    (e.command && e.command.toLowerCase().includes(q))
  );
  res.json({ results, count: results.length });
});

// Comando RCON — implementação nativa em JS (não depende de binário mcrcon instalado)
app.post('/api/rcon', async (req, res) => {
  const { command } = req.body;
  if (!command) return res.status(400).json({ error: 'command required' });
  if (!CONFIG.rconEnabled) {
    return res.json({ output: '[RCON desativado] Habilite enable-rcon=true no server.properties e RCON_ENABLED=true no .env', success: false });
  }
  try {
    const out = await rconCommand({
      host: CONFIG.rconHost, port: CONFIG.rconPort, password: CONFIG.rconPass, command,
    });
    res.json({ output: out.trim() || '(sem saída)', success: true });
  } catch (e) {
    res.json({ output: e.message, success: false });
  }
});

// ── AUTENTICAÇÃO ───────────────────────────────────────────────────────────
app.post('/api/login', (req, res) => auth.login(req, res, { adminPassword: CONFIG.adminPassword, secret: CONFIG.sessionSecret }));
app.post('/api/logout', (req, res) => auth.logout(req, res));
app.get('/api/session', (req, res) => res.json({ authenticated: auth.checkSession(req, { adminPassword: CONFIG.adminPassword, secret: CONFIG.sessionSecret }), requiresPassword: !!CONFIG.adminPassword }));

// ── CONTROLE DO SERVIDOR (start/stop/restart) ──────────────────────────────
app.get('/api/server/status', (req, res) => {
  const sessions = screenMgr.listSessions(CONFIG.screenName);
  res.json({ running: screenMgr.isRunning(CONFIG.screenName), sessions, screenName: CONFIG.screenName });
});

app.post('/api/server/start', (req, res) => {
  const result = screenMgr.startServer({ screenName: CONFIG.screenName, serverDir: CONFIG.serverDir, startCmd: CONFIG.startCmd });
  res.json(result);
});

app.post('/api/server/stop', async (req, res) => {
  const result = await screenMgr.stopServer({ screenName: CONFIG.screenName, gracefulCommand: CONFIG.gracefulStopCmd });
  res.json(result);
});

app.post('/api/server/restart', async (req, res) => {
  const result = await screenMgr.restartServer({ screenName: CONFIG.screenName, serverDir: CONFIG.serverDir, startCmd: CONFIG.startCmd, gracefulCommand: CONFIG.gracefulStopCmd });
  res.json(result);
});

app.post('/api/server/kill', (req, res) => {
  const result = screenMgr.killServer(CONFIG.screenName);
  res.json(result);
});

// Envia qualquer comando direto pro console do jogo via screen (alternativa ao RCON)
app.post('/api/server/console', (req, res) => {
  const { command } = req.body;
  if (!command) return res.status(400).json({ error: 'command required' });
  const result = screenMgr.sendToScreen(CONFIG.screenName, command);
  res.json(result);
});

// ── BACKUP DO MUNDO ─────────────────────────────────────────────────────────
app.post('/api/backup/create', (req, res) => {
  const result = backup.backupWorld({ serverDir: CONFIG.serverDir, backupsDir: CONFIG.backupsDir });
  res.json(result);
});

app.get('/api/backup/list', (req, res) => {
  res.json({ backups: backup.listBackups(CONFIG.backupsDir) });
});

app.get('/api/backup/download/:filename', (req, res) => {
  const { filename } = req.params;
  if (filename.includes('..') || filename.includes('/')) return res.status(400).json({ error: 'invalid' });
  const full = path.join(CONFIG.backupsDir, filename);
  if (!fs.existsSync(full)) return res.status(404).json({ error: 'not found' });
  res.download(full);
});

app.delete('/api/backup/:filename', (req, res) => {
  const result = backup.deleteBackup(CONFIG.backupsDir, req.params.filename);
  res.json(result);
});

// ── WHITELIST / OPS / BANS ───────────────────────────────────────────────────
app.get('/api/whitelist', (req, res) => res.json({ list: configEditor.getWhitelist(CONFIG.serverDir) }));
app.post('/api/whitelist/add', (req, res) => res.json(configEditor.addToWhitelist(CONFIG.serverDir, req.body.name)));
app.post('/api/whitelist/remove', (req, res) => res.json(configEditor.removeFromWhitelist(CONFIG.serverDir, req.body.name)));

app.get('/api/ops', (req, res) => res.json({ list: configEditor.getOps(CONFIG.serverDir) }));
app.post('/api/ops/remove', (req, res) => res.json(configEditor.removeOp(CONFIG.serverDir, req.body.name)));
// Nota: para OPAR um player, o caminho correto é via console ("op nome"), que já preenche UUID certo.
app.post('/api/ops/add', (req, res) => {
  const result = screenMgr.sendToScreen(CONFIG.screenName, `op ${req.body.name}`);
  res.json(result.ok
    ? { ok: true, message: `Comando "op ${req.body.name}" enviado ao console.` }
    : result);
});

app.get('/api/bans/players', (req, res) => res.json({ list: configEditor.getBannedPlayers(CONFIG.serverDir) }));
app.get('/api/bans/ips', (req, res) => res.json({ list: configEditor.getBannedIps(CONFIG.serverDir) }));
app.post('/api/bans/add', (req, res) => {
  const { name, reason } = req.body;
  const cmd = reason ? `ban ${name} ${reason}` : `ban ${name}`;
  const result = screenMgr.sendToScreen(CONFIG.screenName, cmd);
  res.json(result.ok ? { ok: true, message: `Comando "${cmd}" enviado ao console.` } : result);
});
app.post('/api/bans/remove', (req, res) => res.json(configEditor.unbanPlayer(CONFIG.serverDir, req.body.name)));

// ── SERVER.PROPERTIES ────────────────────────────────────────────────────────
app.get('/api/properties', (req, res) => res.json(configEditor.getServerProperties(CONFIG.serverDir)));
app.post('/api/properties', (req, res) => {
  const { key, value } = req.body;
  if (!key) return res.status(400).json({ ok: false, message: 'key required' });
  const result = configEditor.setServerProperty(CONFIG.serverDir, key, value);
  res.json(result);
});

// Config atual
app.get('/api/config', (req, res) => {
  res.json({
    serverDir:    CONFIG.serverDir,
    logFile:      CONFIG.logFile,
    backupsDir:   CONFIG.backupsDir,
    rconEnabled:  CONFIG.rconEnabled,
    rconHost:     CONFIG.rconHost,
    rconPort:     CONFIG.rconPort,
    screenName:   CONFIG.screenName,
    passwordProtected: !!CONFIG.adminPassword,
  });
});

// ── START ──────────────────────────────────────────────────────────────────
app.listen(PORT, '0.0.0.0', () => {
  console.log(`\n🟢 Minecraft Panel rodando em http://0.0.0.0:${PORT}\n`);
  console.log(`   Servidor MC: ${CONFIG.serverDir}`);
  console.log(`   Log:         ${CONFIG.logFile}\n`);
});


// ── TERMINAL AO VIVO (Server-Sent Events — tail do log, 100% Node.js) ───────
const sseClients = new Set();

app.get('/api/terminal/stream', (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no');
  res.flushHeaders();

  // Histórico inicial: últimas 80 linhas
  const history = readTail(CONFIG.logFile, 80);
  for (const line of history) {
    res.write(`data: ${JSON.stringify({ line, hist: true })}\n\n`);
  }

  // Posição inicial = tamanho atual do arquivo (só lê o que vier depois)
  let lastSize = 0;
  try { lastSize = fs.existsSync(CONFIG.logFile) ? fs.statSync(CONFIG.logFile).size : 0; } catch {}
  let pending = '';

  function readNewData() {
    try {
      if (!fs.existsSync(CONFIG.logFile)) return;
      const stat = fs.statSync(CONFIG.logFile);
      if (stat.size < lastSize) {
        // arquivo foi truncado/rotacionado (ex: reinício do servidor) — recomeça do início
        lastSize = 0;
      }
      if (stat.size === lastSize) return;

      const fd = fs.openSync(CONFIG.logFile, 'r');
      const len = stat.size - lastSize;
      const buf = Buffer.alloc(len);
      fs.readSync(fd, buf, 0, len, lastSize);
      fs.closeSync(fd);
      lastSize = stat.size;

      pending += buf.toString('utf8');
      const parts = pending.split('\n');
      pending = parts.pop(); // guarda linha incompleta para o próximo evento
      for (const line of parts) {
        if (!line) continue;
        if (res.writableEnded) return;
        res.write(`data: ${JSON.stringify({ line })}\n\n`);
      }
    } catch { /* arquivo pode estar bloqueado momentaneamente — ignora e tenta de novo */ }
  }

  // fs.watch é leve e cross-platform (Windows/Linux/Mac); fallback por polling abaixo via heartbeat
  let watcher = null;
  try {
    const dir = path.dirname(CONFIG.logFile);
    const targetName = path.basename(CONFIG.logFile);
    watcher = fs.watch(dir, (eventType, filename) => {
      if (filename === targetName) readNewData();
    });
  } catch { /* watch pode falhar em alguns sistemas de arquivo — heartbeat cobre isso */ }

  // Heartbeat de segurança: garante atualização mesmo se o watch falhar/perder eventos
  const heartbeat = setInterval(readNewData, 1000);

  const client = { res };
  sseClients.add(client);
  req.on('close', () => {
    clearInterval(heartbeat);
    if (watcher) watcher.close();
    sseClients.delete(client);
  });
});
